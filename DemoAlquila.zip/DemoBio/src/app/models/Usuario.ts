export class Usuario{
idUsuario:number=0
nombreUsuario:string=""
apellidoUsuario:string=""
dniUsuario:string=""
correoUsuario:string=""
contrasenaUsuario:string=""
edadUsuario:number=0
fotoUsuario:string=""
estadoCivilUsuario:string=""
descripcionUsuario:string=""
}