import { Contrato } from "./Contrato"

export class ContratoClau {
  idClausula: number = 0
  textoClausula: string = ''
  contrato:Contrato=new Contrato()

}
