import { Usuario } from "./Usuario"

export class Soporte{
idSoporte:number=0
usuario:Usuario=new Usuario()
mensaje:string=""
estado:string=""
fecha:Date=new Date()
}