import { Routes } from '@angular/router';
import { Proveedor } from './components/proveedor/proveedor';
import { Proveedorinsert } from './components/proveedor/proveedorinsert/proveedorinsert';
import { Proveedorsearch } from './components/proveedor/proveedorsearch/proveedorsearch';
import { Software } from './components/software/software';
import { Softwareinsert } from './components/software/softwareinsert/softwareinsert';
import { Softwaresearch } from './components/software/softwaresearch/softwaresearch';
import { Contrato } from './models/Contrato';
import { ContratoClau } from './models/ContratoClau';

export const routes: Routes = [
    {
       
    path: 'contratos',
    component: Contrato,
      children: [
      { path: 'news', component: Proveedorinsert },
      { path: 'edits/:id', component: Proveedorinsert },
      {path:'searchs',component:Proveedorsearch}

    ],
    },
      {
       
    path: 'contratos/clausulas',
    component: ContratoClau,
      children: [
      { path: 'news', component: Softwareinsert },
      { path: 'edits/:id', component: Softwareinsert },
      {path:'searchs',component:Softwaresearch}

    ],
    }
];
