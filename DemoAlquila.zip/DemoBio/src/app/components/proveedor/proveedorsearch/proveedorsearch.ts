import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Proveedor } from '../../../models/proveedor';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Proveedorservice } from '../../../services/proveedorservice';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule, MatLabel } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-proveedorsearch',
  imports: [  MatTableModule,
    ReactiveFormsModule,
    CommonModule,
    MatLabel,
    MatFormFieldModule,
    MatInputModule],
  templateUrl: './proveedorsearch.html',
  styleUrl: './proveedorsearch.css',
})
export class Proveedorsearch implements OnInit
{

dataSource: MatTableDataSource<Proveedor> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6','c7'];
  nombrebusqueda: string = "";
  mensaje: string = "";  
  form: FormGroup; 

  constructor(private pS: Proveedorservice, private fb: FormBuilder) {

    this.form = this.fb.group({
      nombrebusqueda: [''],
    });

  }
  ngOnInit(): void {
    this.pS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
      this.form.get('nombrebusqueda')?.valueChanges.subscribe((value) => {
      this.nombrebusqueda = value; 
      this.buscar(); 
    });
  }
  
buscar() {
  const termino = this.nombrebusqueda.trim();

  if (termino === '') {
    // Si el campo está vacío → listar todos los registros
    this.pS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
    return;
  }

  // Si hay texto → buscar coincidencias
  this.pS.searchName(termino).subscribe((data) => {
    this.dataSource = new MatTableDataSource(data);
  });
}
}


