import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { Proveedorlistar } from './proveedorlistar/proveedorlistar';

@Component({
  selector: 'app-proveedor',
  imports: [RouterOutlet,Proveedorlistar],
  templateUrl: './proveedor.html',
  styleUrl: './proveedor.css',
})
export class Proveedor {


  constructor(public route:ActivatedRoute){}
}
