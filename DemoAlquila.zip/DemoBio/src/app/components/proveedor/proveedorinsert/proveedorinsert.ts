import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { Proveedor } from '../../../models/proveedor';
import { Proveedorservice } from '../../../services/proveedorservice';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule, provideNativeDateAdapter } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';

@Component({
  selector: 'app-proveedorinsert',
  imports: [
    MatFormFieldModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatRadioModule,
  ],
  templateUrl: './proveedorinsert.html',
  providers: [provideNativeDateAdapter()],

  styleUrl: './proveedorinsert.css',
})
export class Proveedorinsert implements OnInit {
  form: FormGroup = new FormGroup({});
  prov: Proveedor = new Proveedor();
  id: number = 0;
  today = new Date(); 

  edicion: boolean = false;
  estado: boolean = true;

  tipos: { value: string; viewValue: string }[] = [
    { value: 'Público', viewValue: 'Público' },
    { value: 'Privado', viewValue: 'Privado' },
  ];

  constructor(
    private pS: Proveedorservice,
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((data: Params) => {
      this.id = data['id'];
      this.edicion = data['id'] != null;
      this.init();
    });

    this.form = this.formBuilder.group({
      id: [''],
      name: ['', Validators.required],
      adress: ['', Validators.required],
      phone: ['', Validators.required],
      status: [false, Validators.required],
      type: ['', Validators.required],
      date: ['', Validators.required],
      amount: ['', Validators.required],
    });
  }
  aceptar(): void {
    if (this.form.valid) {
     
       this.prov.idProvider = this.form.value.id;
      this.prov.nameProvider = this.form.value.name;
      this.prov.adressProvider = this.form.value.adress;
      this.prov.phoneProvider = this.form.value.phone;
      this.prov.statusProvider = this.form.value.status;
      this.prov.typeProvider = this.form.value.type;
      this.prov.dateRegisterProvider = this.form.value.date;
      this.prov.amountWarrantyProvider = this.form.value.amount;
      if (this.edicion) {
        this.pS.update(this.prov).subscribe(() => {
          this.pS.list().subscribe((data) => {
            this.pS.setList(data);
          });
        });
      } else {
        this.pS.insert(this.prov).subscribe((data) => {
          this.pS.list().subscribe((data) => {
            this.pS.setList(data);
          });
        });
      }
      this.router.navigate(['providers']);
    }
      
    }
  init() {
    if (this.edicion) {
      this.pS.listId(this.id).subscribe((data) => {     
        this.form = new FormGroup({
          id: new FormControl(data.idProvider),
          name: new FormControl(data.nameProvider),
          adress: new FormControl(data.adressProvider),
          phone: new FormControl(data.phoneProvider),
          status: new FormControl(data.statusProvider),
          type: new FormControl(data.typeProvider),
          date: new FormControl(data.dateRegisterProvider),
          amount: new FormControl(data.amountWarrantyProvider),
        });
      });
    }
  }
   
}
