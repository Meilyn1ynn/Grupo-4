import { Component, OnInit } from '@angular/core';
import { Software } from '../../../models/ContratoClau';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Softwareservice } from '../../../services/softwareservice';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-softwarelist',
  imports: [MatTableModule, CommonModule, RouterLink, MatButtonModule, MatIconModule],
  templateUrl: './softwarelist.html',
  styleUrl: './softwarelist.css',
})
export class Softwarelist implements OnInit {
  dataSource: MatTableDataSource<Software> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6',  'c7','c8', 'c9'];

  constructor(private sS: Softwareservice) {}

  ngOnInit(): void {
    this.sS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
    this.sS.getList().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }
  eliminar(id: number) {
    this.sS.delete(id).subscribe((data) => {
      this.sS.list().subscribe((data) => {
        this.sS.setList(data);
      });
    });
  }
}
