import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { Softwarelist } from './softwarelist/softwarelist';

@Component({
  selector: 'app-software',
  imports: [RouterOutlet,Softwarelist],
  templateUrl: './software.html',
  styleUrl: './software.css',
})
export class Software {
  constructor(public route:ActivatedRoute){}

}
