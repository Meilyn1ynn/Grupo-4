import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Software } from '../../../models/ContratoClau';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Softwareservice } from '../../../services/softwareservice';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule, MatLabel } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';

@Component({
  selector: 'app-softwaresearch',
  imports: [
    MatTableModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    CommonModule,
    MatLabel,
    MatFormFieldModule,
    MatInputModule,
  ],
  templateUrl: './softwaresearch.html',
  providers: [provideNativeDateAdapter()],

  styleUrl: './softwaresearch.css',
})
export class Softwaresearch implements OnInit {
  dataSource: MatTableDataSource<Software> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7'];
  hoy: Date = new Date();
  form: FormGroup;
  mensaje: string = '';

  constructor(private sS: Softwareservice, private fb: FormBuilder) {
    this.form = this.fb.group({
      fechabusqueda: [''],
    });
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      fechabusqueda: [this.hoy],
    });

    this.buscar(this.hoy);

    this.form.get('fechabusqueda')?.valueChanges.subscribe((fecha: Date | null) => {
      this.buscar(fecha);
    });
  }

  buscar(fecha: Date | string | null): void {
  this.mensaje = ''; // limpiar mensaje previo

  if (!fecha) {
    this.sS.list().subscribe({
      next: (data) => {
        this.dataSource = new MatTableDataSource<Software>(data);
        this.mensaje = data.length === 0 ? 'No hay registros disponibles.' : '';
      },
      error: (err) => {
        console.error('Error al listar:', err);
        this.mensaje = 'Error al obtener los registros.';
      },
    });
    return;
  }

  let fechaDate: Date;
  if (fecha instanceof Date) {
    fechaDate = fecha;
  } else if (typeof fecha === 'string') {
    fechaDate = new Date(fecha);
  } else {
    console.error('Formato de fecha no válido:', fecha);
    this.mensaje = 'Formato de fecha inválido.';
    return;
  }

  this.sS.search(fechaDate).subscribe({
    next: (data) => {
      this.dataSource = new MatTableDataSource<Software>(data);
      this.mensaje = data.length === 0 ? 'No se encontraron registros.' : '';
    },
    error: (err) => {
      if (err.status === 404) {
        this.mensaje = err.error; 
      } else {
        this.mensaje = 'Ocurrió un error al buscar los registros.';
      }
      this.dataSource = new MatTableDataSource<Software>([]); 
    },
  });
}
}
