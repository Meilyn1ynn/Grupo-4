import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Software } from '../../../models/ContratoClau';
import { Softwaresearch } from '../softwaresearch/softwaresearch';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Softwareservice } from '../../../services/softwareservice';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { Proveedorservice } from '../../../services/proveedorservice';
import { Proveedor } from '../../../models/proveedor';

@Component({
  selector: 'app-softwareinsert',
  imports: [
    MatFormFieldModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatRadioModule,
  ],
  templateUrl: './softwareinsert.html',
  styleUrl: './softwareinsert.css',
})
export class Softwareinsert implements OnInit {
  form: FormGroup = new FormGroup({});
  soft: Software = new Software();
  id: number = 0;
  today = new Date();
  listaProveedores:Proveedor[]=[]

  edicion: boolean = false;
  estado: boolean = true;

  tipos: { value: string; viewValue: string }[] = [
    { value: 'OpenSource', viewValue: 'OpenSource' },
    { value: 'Privado', viewValue: 'Privado' },
  ];

  constructor(
    private sS: Softwareservice,
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private pS: Proveedorservice
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((data: Params) => {
      this.id = data['id'];
      this.edicion = data['id'] != null;
      this.init();
    });

   this.pS.list().subscribe(data=>{
    this.listaProveedores=data
   })

    this.form = this.formBuilder.group({
      id: [''],
      nombre: ['', Validators.required],
      version: ['', Validators.required],
      tipo: ['', Validators.required],
      licencia: ['', Validators.required],
      estado: [false, Validators.required],
      fecha: ['', Validators.required],
      foraneo:['',Validators.required]
    });
  }
  aceptar(): void {
    if (this.form.valid) {
      this.soft.idSoftware = this.form.value.id;
      this.soft.nameSoftware = this.form.value.nombre;
      this.soft.versionSoftware = this.form.value.version;
      this.soft.typeSoftware = this.form.value.tipo;
      this.soft.licenseSoftware = this.form.value.licencia;
      this.soft.statusSoftware = this.form.value.estado;
      this.soft.purchaseDate = this.form.value.fecha;
      this.soft.provider.idProvider=this.form.value.foraneo
      if (this.edicion) {
        this.sS.update(this.soft).subscribe(() => {
          this.sS.list().subscribe((data) => {
            this.sS.setList(data);
          });
        });
      } else {
        this.sS.insert(this.soft).subscribe((data) => {
          this.sS.list().subscribe((data) => {
            this.sS.setList(data);
          });
        });
      }
      this.router.navigate(['softwares']);
    }
  }
  init() {
    if (this.edicion) {
      this.sS.listId(this.id).subscribe((data) => {
        this.form = new FormGroup({
          id: new FormControl(data.idSoftware),
          nombre: new FormControl(data.nameSoftware),
          version: new FormControl(data.versionSoftware),
          tipo: new FormControl(data.typeSoftware),
          licencia: new FormControl(data.licenseSoftware),
          estado: new FormControl(data.statusSoftware),
          fecha: new FormControl(data.purchaseDate),
          foraneo:new FormControl(data.provider.idProvider)
        });
      });
    }
  }
}
