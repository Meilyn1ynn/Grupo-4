package pe.edu.upc.entities;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "usuario")
public class Usuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idUsuario;

    @Column(name = "username",length = 50, nullable = false, unique = true)
    private String username;
    @Column(name = "password", length = 150, nullable = false)
    private String password;
    private Boolean enabled;

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private List<Rol> roles;

    @Column(name = "Us_apellido", nullable = false)
    private String apellidoUsuario;

    @Column(name = "Us_dni", nullable = false, unique = true)
    private int dniUsuario;

    @Column(name = "correo", length = 50, nullable = false)
    private String correo;

    @Column(name = "Us_edad")
    private Integer edadUsuario;

    @Column(name = "Us_foto")
    private String fotoUsuario;

    @Column(name = "Us_estado_civil")
    private String estadoCivilUsuario;

    // Constructor vacío requerido por JPA
    public Usuario() {}


    public Usuario(int idUsuario, String username, String password, Boolean enabled, List<Rol> roles, String apellidoUsuario, int dniUsuario, String correo, Integer edadUsuario, String fotoUsuario, String estadoCivilUsuario, List<Propiedad> propiedades) {
        this.idUsuario = idUsuario;
        this.username = username;
        this.password = password;
        this.enabled = enabled;
        this.roles = roles;
        this.apellidoUsuario = apellidoUsuario;
        this.dniUsuario = dniUsuario;
        this.correo = correo;
        this.edadUsuario = edadUsuario;
        this.fotoUsuario = fotoUsuario;
        this.estadoCivilUsuario = estadoCivilUsuario;

    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public List<Rol> getRoles() {
        return roles;
    }

    public void setRoles(List<Rol> roles) {
        this.roles = roles;
    }


    public String getApellidoUsuario() {
        return apellidoUsuario;
    }

    public void setApellidoUsuario(String apellidoUsuario) {
        this.apellidoUsuario = apellidoUsuario;
    }

    public int getDniUsuario() {
        return dniUsuario;
    }

    public void setDniUsuario(int dniUsuario) {
        this.dniUsuario = dniUsuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public Integer getEdadUsuario() {
        return edadUsuario;
    }

    public void setEdadUsuario(Integer edadUsuario) {
        this.edadUsuario = edadUsuario;
    }

    public String getFotoUsuario() {
        return fotoUsuario;
    }

    public void setFotoUsuario(String fotoUsuario) {
        this.fotoUsuario = fotoUsuario;
    }

    public String getEstadoCivilUsuario() {
        return estadoCivilUsuario;
    }

    public void setEstadoCivilUsuario(String estadoCivilUsuario) {
        this.estadoCivilUsuario = estadoCivilUsuario;
    }


}
