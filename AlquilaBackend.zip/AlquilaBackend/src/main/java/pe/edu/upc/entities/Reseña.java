package pe.edu.upc.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "Reseña")
public class Reseña {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Re_id")
    private int idReseña;

    @ManyToOne
    @JoinColumn(name = "Us_id", nullable = false)
    private Usuario usuario;

    @Column(name = "Re_puntaje")
    private Integer puntaje;

    @Column(name = "Re_comentario")
    private String comentario;

    @Column(name = "Re_fecha")
    private Date fecha;

    public Reseña(){}

    public Reseña(int idReseña, Usuario usuario, Integer puntaje, String comentario, Date fecha) {
        this.idReseña = idReseña;
        this.usuario = usuario;
        this.puntaje = puntaje;
        this.comentario = comentario;
        this.fecha = fecha;
    }

    public int getIdReseña() {
        return idReseña;
    }

    public void setIdReseña(int idReseña) {
        this.idReseña = idReseña;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Integer getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(Integer puntaje) {
        this.puntaje = puntaje;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
