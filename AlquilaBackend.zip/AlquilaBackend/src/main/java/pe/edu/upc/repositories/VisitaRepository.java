package pe.edu.upc.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.Visita;

import java.util.List;

@Repository
public interface VisitaRepository extends JpaRepository<Visita, Integer> {

    // Listar visitas de un usuario específico
    @Query("SELECT v FROM Visita v WHERE v.usuario.idUsuario = :idUsuario")
    List<Visita> listarPorInquilino(@Param("idUsuario") Integer idUsuario);

    // Listar visitas de una propiedad específica
    @Query("SELECT v FROM Visita v WHERE v.propiedad.idPropiedad = :idPropiedad")
    List<Visita> listarPorPropiedad(@Param("idPropiedad") Integer idPropiedad);

    // Buscar visitas por estado (pendiente, confirmada, cancelada)
    List<Visita> findByEstado(String estado);
}