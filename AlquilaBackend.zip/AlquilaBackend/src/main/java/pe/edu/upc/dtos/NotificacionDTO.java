package pe.edu.upc.dtos;

import java.time.LocalDateTime;

public class NotificacionDTO {
    private int idContrato;
    private int idUsuario;
    private String titulo;
    private String mensaje;
    private LocalDateTime fecha;
    private String leida;

    public NotificacionDTO() {}

    public NotificacionDTO(int idContrato, int idUsuario, String titulo, String mensaje, LocalDateTime fecha, String leida) {
        this.idContrato = idContrato;
        this.idUsuario = idUsuario;
        this.titulo = titulo;
        this.mensaje = mensaje;
        this.fecha = fecha;
        this.leida = leida;
    }

    public int getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public String getLeida() {
        return leida;
    }

    public void setLeida(String leida) {
        this.leida = leida;
    }
}
