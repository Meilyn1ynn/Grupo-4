package pe.edu.upc.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.entities.Contrato;
import pe.edu.upc.repositories.ContratoRepository;
import pe.edu.upc.serviceinterfaces.IContratoService;


import java.util.List;

@Service
public class ContratoServiceImplement implements IContratoService {

    @Autowired
    private ContratoRepository repository;

    @Override
    public List<Contrato> list() {
        return repository.findAll();
    }

    @Override
    public void insert(Contrato contrato) {
        repository.save(contrato);
    }

    @Override
    public Contrato listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(Contrato contrato) {
        repository.save(contrato);
    }

    @Override
    public List<Contrato> contratosPorUsuario(int idUsuario) {
        return List.of();
    }
}
