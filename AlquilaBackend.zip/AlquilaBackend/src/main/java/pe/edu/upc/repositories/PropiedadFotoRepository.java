package pe.edu.upc.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.PropiedadFoto;

import java.util.List;

@Repository
public interface PropiedadFotoRepository extends JpaRepository<PropiedadFoto, Integer> {

    // Obtener fotos de una propiedad
    @Query("SELECT f FROM PropiedadFoto f WHERE f.propiedad.idPropiedad = :idPropiedad")
    List<PropiedadFoto> fotosPorPropiedad(@Param("idPropiedad") Integer idPropiedad);
}