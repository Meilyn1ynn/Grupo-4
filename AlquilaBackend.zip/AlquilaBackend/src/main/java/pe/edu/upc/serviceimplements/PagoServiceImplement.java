package pe.edu.upc.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.entities.Pago;
import pe.edu.upc.repositories.PagoRepository;
import pe.edu.upc.serviceinterfaces.IPagoService;

import java.util.List;

@Service
public class PagoServiceImplement implements IPagoService {

    @Autowired
    private PagoRepository repository;

    @Override
    public List<Pago> list() {
        return repository.findAll();
    }

    @Override
    public void insert(Pago pago) {
        repository.save(pago);
    }

    @Override
    public Pago listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(Pago pago) {
        repository.save(pago);
    }

    @Override
    public List<Pago> pagosPorContrato(int idContrato) {
        return repository.pagosPorContrato(idContrato);
    }
}