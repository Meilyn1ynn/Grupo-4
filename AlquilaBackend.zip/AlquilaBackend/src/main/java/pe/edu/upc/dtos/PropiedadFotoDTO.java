package pe.edu.upc.dtos;

public class PropiedadFotoDTO {
    private Integer idContrato;
    private String urlFoto;
    private int idPropiedad;

    public PropiedadFotoDTO() {}

    public PropiedadFotoDTO(Integer idContrato, String urlFoto, int idPropiedad) {
        this.idContrato = idContrato;
        this.urlFoto = urlFoto;
        this.idPropiedad = idPropiedad;
    }

    public Integer getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(Integer idContrato) {
        this.idContrato = idContrato;
    }

    public String getUrlFoto() {
        return urlFoto;
    }

    public void setUrlFoto(String urlFoto) {
        this.urlFoto = urlFoto;
    }

    public int getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(int idPropiedad) {
        this.idPropiedad = idPropiedad;
    }
}
