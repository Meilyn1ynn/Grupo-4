package pe.edu.upc.dtos;

import pe.edu.upc.entities.Propiedad;

public class PropiedadFotoDTO {
    private int idFoto;
    private String url;
    private Propiedad propiedad;

    public PropiedadFotoDTO() {}

    public int getIdFoto() {
        return idFoto;
    }

    public void setIdFoto(int idFoto) {
        this.idFoto = idFoto;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }
}
