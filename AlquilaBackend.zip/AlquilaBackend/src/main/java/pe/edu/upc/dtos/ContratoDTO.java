package pe.edu.upc.dtos;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class ContratoDTO {
    private int idContrato;
    private Date fechaInicio;
    private Date fechaFin;
    private String estado;
    private String pdf;
    private int idPropiedad;
    private int idUsuario;

    public ContratoDTO() {}

    public ContratoDTO(int idContrato, Date fechaInicio, Date fechaFin, String estado, String pdf, int idPropiedad, int idUsuario) {
        this.idContrato = idContrato;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
        this.pdf = pdf;
        this.idPropiedad = idPropiedad;
        this.idUsuario = idUsuario;
    }

    public int getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public int getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(int idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}
