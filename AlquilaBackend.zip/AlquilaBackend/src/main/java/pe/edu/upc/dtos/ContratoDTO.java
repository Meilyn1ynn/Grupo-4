package pe.edu.upc.dtos;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import pe.edu.upc.entities.Usuario;   // <--- IMPORTANTE: Agrega esto
import pe.edu.upc.entities.Propiedad; // <--- IMPORTANTE: Agrega esto

public class ContratoDTO {
    private int idContrato;
    private Date fechaInicio;
    private Date fechaFin;
    private String estado;
    private String pdf;


    private Usuario usuario;
    private Propiedad propiedad;


    public ContratoDTO() {}

    public ContratoDTO(int idContrato, Date fechaInicio, Date fechaFin, String estado, String pdf, Usuario usuario, Propiedad propiedad) {
        this.idContrato = idContrato;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
        this.pdf = pdf;
        this.usuario = usuario;
        this.propiedad = propiedad;
    }

    public int getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    // --- GETTERS Y SETTERS QUE FALTABAN ---
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }
}