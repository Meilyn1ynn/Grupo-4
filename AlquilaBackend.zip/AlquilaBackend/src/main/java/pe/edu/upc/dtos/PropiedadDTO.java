package pe.edu.upc.dtos;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;


public class PropiedadDTO {
    private int idPropiedad;
    private String titulo;
    private String descripcion;
    private String direccion;
    private String distrito;
    private Double precio;
    private Integer habitaciones;
    private Date fechaPublicacion;
    private int usuarioId;

    public PropiedadDTO() {}

    public PropiedadDTO(int idPropiedad, String titulo, String descripcion, String direccion, String distrito, Double precio, Integer habitaciones, Date fechaPublicacion, int usuarioId) {
        this.idPropiedad = idPropiedad;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.direccion = direccion;
        this.distrito = distrito;
        this.precio = precio;
        this.habitaciones = habitaciones;
        this.fechaPublicacion = fechaPublicacion;
        this.usuarioId = usuarioId;
    }

    public int getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(int idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Integer getHabitaciones() {
        return habitaciones;
    }

    public void setHabitaciones(Integer habitaciones) {
        this.habitaciones = habitaciones;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
