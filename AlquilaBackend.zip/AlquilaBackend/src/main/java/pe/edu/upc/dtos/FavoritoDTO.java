package pe.edu.upc.dtos;

import pe.edu.upc.entities.Propiedad;
import pe.edu.upc.entities.Usuario;

import java.time.LocalDateTime;
import java.util.Date;

public class FavoritoDTO {
    private int idFavorito;
    private Usuario usuario;
    private Propiedad propiedad;
    private Date fecha;

    public FavoritoDTO() {}

    public int getIdFavorito() {
        return idFavorito;
    }

    public void setIdFavorito(int idFavorito) {
        this.idFavorito = idFavorito;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
