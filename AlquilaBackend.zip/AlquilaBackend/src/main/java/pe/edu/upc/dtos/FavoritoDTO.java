package pe.edu.upc.dtos;

import java.time.LocalDateTime;
import java.util.Date;

public class FavoritoDTO {
    private int idFavorito;
    private int idUsuario;
    private int idPropiedad;
    private Date fecha;

    public FavoritoDTO() {}

    public FavoritoDTO(int idFavorito, int idUsuario, int idPropiedad, Date fecha) {
        this.idFavorito = idFavorito;
        this.idUsuario = idUsuario;
        this.idPropiedad = idPropiedad;
        this.fecha = fecha;
    }

    public int getIdFavorito() {
        return idFavorito;
    }

    public void setIdFavorito(int idFavorito) {
        this.idFavorito = idFavorito;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(int idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
