package pe.edu.upc.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.Favorito;

import java.util.List;

@Repository
public interface FavoritoRepository extends JpaRepository<Favorito, Integer> {

    // Listar favoritos por usuario
    @Query("SELECT f FROM Favorito f WHERE f.usuario.idUsuario = :idUsuario")
    List<Favorito> listarFavoritosPorUsuario(@Param("idUsuario") Integer idUsuario);

    // Verificar si una propiedad ya está en favoritos
    @Query("SELECT COUNT(f) > 0 FROM Favorito f WHERE f.usuario.idUsuario = :idUsuario AND f.propiedad.idPropiedad = :idPropiedad")
    boolean existeFavorito(@Param("idUsuario") Integer idUsuario, @Param("idPropiedad") Integer idPropiedad);
}
