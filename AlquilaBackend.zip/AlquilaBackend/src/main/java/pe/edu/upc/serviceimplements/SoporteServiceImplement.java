package pe.edu.upc.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.entities.Soporte;
import pe.edu.upc.repositories.SoporteRepository;
import pe.edu.upc.serviceinterfaces.ISoporteService;

import java.util.List;

@Service
public class SoporteServiceImplement implements ISoporteService {

    @Autowired
    private SoporteRepository repository;

    @Override
    public List<Soporte> list() {
        return repository.findAll();
    }

    @Override
    public void insert(Soporte soporte) {
        repository.save(soporte);
    }

    @Override
    public Soporte listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(Soporte soporte) {
        repository.save(soporte);
    }

    @Override
    public List<Soporte> soportePorUsuario(int idUsuario) {
        return repository.listarTicketsPorUsuario(idUsuario);
    }
}