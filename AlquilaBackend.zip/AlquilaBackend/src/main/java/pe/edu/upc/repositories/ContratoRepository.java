package pe.edu.upc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.Contrato;

import java.util.List;

@Repository
public interface ContratoRepository extends JpaRepository<Contrato, Integer> {

    // Contratos activos por propietario
    @Query("SELECT c FROM Contrato c WHERE c.propiedad.usuario.idUsuario = :idPropietario AND c.estado = 'Activo'")
    List<Contrato> contratosActivosPorPropietario(@Param("idPropietario") Integer idPropietario);

    // Contratos activos por inquilino
    @Query("SELECT c FROM Contrato c WHERE c.usuario.idUsuario = :idInquilino AND c.estado = 'Activo'")
    List<Contrato> contratosActivosPorInquilino(@Param("idInquilino") Integer idInquilino);

    // Contratos por usuario (propietario o inquilino)
    @Query("SELECT c FROM Contrato c WHERE c.usuario.idUsuario = :idUsuario OR c.propiedad.usuario.idUsuario = :idUsuario")
    List<Contrato> contratosPorUsuario(@Param("idUsuario") int idUsuario);
}
