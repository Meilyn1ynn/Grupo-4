package pe.edu.upc.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.ContratoClausula;

import java.util.List;

@Repository
public interface ContratoClausulaRepository extends JpaRepository<ContratoClausula, Integer> {

    @Query("SELECT c FROM ContratoClausula c WHERE c.contrato.idContrato = :idContrato")
    List<ContratoClausula> clausulasPorContrato(@Param("idContrato") Integer idContrato);
}
