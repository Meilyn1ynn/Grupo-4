package pe.edu.upc.dtos;

import java.time.LocalDateTime;
import java.util.Date;

public class VisitaDTO {
    private int idVisita;
    private int idUsuario;
    private int idPropiedad;
    private Date fecha;
    private String estado;

    public  VisitaDTO() {}

    public VisitaDTO(int idVisita, int idUsuario, int idPropiedad, Date fecha, String estado) {
        this.idVisita = idVisita;
        this.idUsuario = idUsuario;
        this.idPropiedad = idPropiedad;
        this.fecha = fecha;
        this.estado = estado;
    }

    public int getIdVisita() {
        return idVisita;
    }

    public void setIdVisita(int idVisita) {
        this.idVisita = idVisita;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(int idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
