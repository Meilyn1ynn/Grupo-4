package pe.edu.upc.dtos;

import pe.edu.upc.entities.Propiedad;
import pe.edu.upc.entities.Usuario;

import java.time.LocalDateTime;
import java.util.Date;

public class VisitaDTO {
    private int idVisita;
    private Usuario usuario;
    private Propiedad propiedad;
    private Date fecha;
    private String estado;

    public  VisitaDTO() {}

    public int getIdVisita() {
        return idVisita;
    }

    public void setIdVisita(int idVisita) {
        this.idVisita = idVisita;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
