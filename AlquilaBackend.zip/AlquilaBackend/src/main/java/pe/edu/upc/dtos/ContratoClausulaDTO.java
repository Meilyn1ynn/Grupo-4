package pe.edu.upc.dtos;

public class ContratoClausulaDTO {
    private int idClausula;
    private int idContrato;
    private String textoClausula;

    public  ContratoClausulaDTO() {}

    public ContratoClausulaDTO(int idClausula, int idContrato, String textoClausula) {
        this.idClausula = idClausula;
        this.idContrato = idContrato;
        this.textoClausula = textoClausula;
    }

    public int getIdClausula() {
        return idClausula;
    }

    public void setIdClausula(int idClausula) {
        this.idClausula = idClausula;
    }

    public int getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    public String getTextoClausula() {
        return textoClausula;
    }

    public void setTextoClausula(String textoClausula) {
        this.textoClausula = textoClausula;
    }
}
