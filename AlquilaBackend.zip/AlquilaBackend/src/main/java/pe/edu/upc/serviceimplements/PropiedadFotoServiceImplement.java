package pe.edu.upc.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.entities.PropiedadFoto;
import pe.edu.upc.repositories.PropiedadFotoRepository;
import pe.edu.upc.serviceinterfaces.IPropiedadFotoService;

import java.util.List;

@Service
public class PropiedadFotoServiceImplement implements IPropiedadFotoService {

    @Autowired
    private PropiedadFotoRepository repository;

    @Override
    public List<PropiedadFoto> list() {
        return repository.findAll();
    }

    @Override
    public void insert(PropiedadFoto f) {
        repository.save(f);
    }

    @Override
    public PropiedadFoto listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(PropiedadFoto f) {
        repository.save(f);
    }

    @Override
    public List<PropiedadFoto> fotosPorPropiedad(int idPropiedad) {
        return repository.fotosPorPropiedad(idPropiedad);
    }
}