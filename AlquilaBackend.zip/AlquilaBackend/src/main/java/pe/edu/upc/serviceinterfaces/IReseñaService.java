package pe.edu.upc.serviceinterfaces;

import pe.edu.upc.entities.Reseña;
import java.util.List;

public interface IReseñaService {
    public List<Reseña> list();
    public void insert(Reseña reseña);
    public Reseña listId(int id);
    public void delete(int id);
    public void edit(Reseña reseña);
    public List<Reseña> reseñasPorUsuario(int idUsuario);

}
