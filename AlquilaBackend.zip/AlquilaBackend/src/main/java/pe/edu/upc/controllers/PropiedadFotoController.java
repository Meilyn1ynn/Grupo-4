package pe.edu.upc.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.dtos.PropiedadFotoDTO;
import pe.edu.upc.entities.PropiedadFoto;
import pe.edu.upc.serviceinterfaces.IPropiedadFotoService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/propiedades/fotos")
public class PropiedadFotoController {

    @Autowired
    private IPropiedadFotoService service;

    @GetMapping
    public List<PropiedadFotoDTO> listar() {
        return service.list().stream().map(f -> {
            ModelMapper m = new ModelMapper();
            return m.map(f, PropiedadFotoDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody PropiedadFotoDTO dto) {
        ModelMapper m = new ModelMapper();
        PropiedadFoto foto = m.map(dto, PropiedadFoto.class);
        service.insert(foto);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        PropiedadFoto foto = service.listId(id);
        if (foto == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe foto con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        PropiedadFotoDTO dto = m.map(foto, PropiedadFotoDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        PropiedadFoto foto = service.listId(id);
        if (foto == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe foto con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Foto con ID " + id + " eliminada correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody PropiedadFotoDTO dto) {
        ModelMapper m = new ModelMapper();
        PropiedadFoto foto = m.map(dto, PropiedadFoto.class);
        PropiedadFoto existente = service.listId(foto.getIdFoto());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe foto con ID: " + foto.getIdFoto());
        }
        service.edit(foto);
        return ResponseEntity.ok("Foto con ID " + foto.getIdFoto() + " modificada correctamente.");
    }
}