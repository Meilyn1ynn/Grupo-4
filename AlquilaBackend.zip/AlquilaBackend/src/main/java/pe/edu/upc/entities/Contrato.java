package pe.edu.upc.entities;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "Contrato")
public class Contrato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Con_id")
    private int idContrato;

    @Column(name = "Con_fecha_inicio", nullable = false)
    private Date fechaInicio;

    @Column(name = "Con_fecha_fin", nullable = false)
    private Date fechaFin;

    @Column(name = "Con_pdf")
    private String pdf;

    @Column(name = "Con_estado")
    private String estado;

    @ManyToOne
    @JoinColumn(name = "Us_id", nullable = false)
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "Pr_id", nullable = false)
    private Propiedad propiedad;

    public Contrato() {}

    public Contrato(int idContrato, Date fechaInicio, Date fechaFin, String pdf, String estado, Usuario usuario, Propiedad propiedad) {
        this.idContrato = idContrato;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.pdf = pdf;
        this.estado = estado;
        this.usuario = usuario;
        this.propiedad = propiedad;
    }

    public int getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }
}
