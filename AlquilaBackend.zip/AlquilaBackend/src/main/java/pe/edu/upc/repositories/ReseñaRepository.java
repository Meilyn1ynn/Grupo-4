package pe.edu.upc.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.Reseña;

import java.util.List;

@Repository
public interface ReseñaRepository extends JpaRepository<Reseña, Integer> {

    // Buscar reseñas de un usuario específico
    @Query("SELECT r FROM Reseña r WHERE r.usuario.idUsuario = :idUsuario")
    List<Reseña> reseñasDeUsuario(@Param("idUsuario") Integer idUsuario);

    // Calcular promedio de puntaje de un usuario específico
    @Query("SELECT AVG(r.puntaje) FROM Reseña r WHERE r.usuario.idUsuario = :idUsuario")
    Double promedioPuntaje(@Param("idUsuario") Integer idUsuario);
}
