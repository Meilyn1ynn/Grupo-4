package pe.edu.upc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.Reseña;

import java.util.List;

@Repository
public interface ReseñaRepository extends JpaRepository<Reseña, Integer> {

    // CORREGIDO: Cambiamos 'r.usuario' por 'r.receptor'
    // (Buscamos las reseñas que ha RECIBIDO el usuario)
    @Query("SELECT r FROM Reseña r WHERE r.receptor.idUsuario = :idUsuario")
    List<Reseña> reseñasDeUsuario(@Param("idUsuario") Integer idUsuario);

    // CORREGIDO: Cambiamos 'r.usuario' por 'r.receptor'
    // (Calculamos el promedio de puntaje del usuario RECEPTOR)
    @Query("SELECT AVG(r.puntaje) FROM Reseña r WHERE r.receptor.idUsuario = :idUsuario")
    Double promedioPuntaje(@Param("idUsuario") Integer idUsuario);
}
