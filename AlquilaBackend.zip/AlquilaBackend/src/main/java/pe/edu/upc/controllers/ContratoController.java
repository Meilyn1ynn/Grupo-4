package pe.edu.upc.controllers;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.dtos.ContratoDTO;
import pe.edu.upc.entities.Contrato;
import pe.edu.upc.serviceinterfaces.IContratoService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/contratos")
public class ContratoController {

    @Autowired
    private IContratoService service;

    @GetMapping
    public List<ContratoDTO> listar() {
        return service.list().stream().map(c -> {
            ModelMapper m = new ModelMapper();
            return m.map(c, ContratoDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody ContratoDTO dto) {
        ModelMapper m = new ModelMapper();
        Contrato contrato = m.map(dto, Contrato.class);
        service.insert(contrato);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Contrato contrato = service.listId(id);
        if (contrato == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe contrato con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        ContratoDTO dto = m.map(contrato, ContratoDTO.class);
        return ResponseEntity.ok(dto);
    }
}