package pe.edu.upc.serviceinterfaces;

import pe.edu.upc.entities.Soporte;
import java.util.List;

public interface ISoporteService {
    public List<Soporte> list();
    public void insert(Soporte soporte);
    public Soporte listId(int id);
    public void delete(int id);
    public void edit(Soporte soporte);
    public List<Soporte> soportePorUsuario(int idUsuario);

}
