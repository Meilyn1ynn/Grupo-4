package pe.edu.upc.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "Visita")
public class Visita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Vi_id")
    private int idVisita;

    @ManyToOne
    @JoinColumn(name = "Us_id", nullable = false)
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "Pr_id", nullable = false)
    private Propiedad propiedad;

    @Column(name = "Vi_fecha", nullable = false)
    private Date fecha;

    @Column(name = "Vi_estado")
    private String estado;

    public Visita() {}

    public Visita(int idVisita, Usuario usuario, Propiedad propiedad, Date fecha, String estado) {
        this.idVisita = idVisita;
        this.usuario = usuario;
        this.propiedad = propiedad;
        this.fecha = fecha;
        this.estado = estado;
    }

    public int getIdVisita() {
        return idVisita;
    }

    public void setIdVisita(int idVisita) {
        this.idVisita = idVisita;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
