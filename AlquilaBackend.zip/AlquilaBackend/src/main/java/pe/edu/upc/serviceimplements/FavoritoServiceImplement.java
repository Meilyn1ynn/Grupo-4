package pe.edu.upc.serviceimplements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.entities.Favorito;
import pe.edu.upc.repositories.FavoritoRepository;
import pe.edu.upc.serviceinterfaces.IFavoritoService;

import java.util.List;

@Service
public class FavoritoServiceImplement implements IFavoritoService {

    @Autowired
    private FavoritoRepository repository;

    @Override
    public List<Favorito> list() {
        return repository.findAll();
    }

    @Override
    public void insert(Favorito favorito) {
        repository.save(favorito);
    }

    @Override
    public Favorito listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(Favorito favorito) {
        repository.save(favorito);
    }

    @Override
    public List<Favorito> favoritosPorUsuario(int idUsuario) {
        return repository.listarFavoritosPorUsuario(idUsuario);
    }
}