package pe.edu.upc.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.dtos.VisitaDTO;
import pe.edu.upc.entities.Visita;
import pe.edu.upc.serviceinterfaces.IVisitaService;


import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/visitas")
public class VisitaController {

    @Autowired
    private IVisitaService service;

    @GetMapping
    public List<VisitaDTO> listar() {
        return service.list().stream().map(v -> {
            ModelMapper m = new ModelMapper();
            return m.map(v, VisitaDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody VisitaDTO dto) {
        ModelMapper m = new ModelMapper();
        Visita visita = m.map(dto, Visita.class);
        service.insert(visita);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Visita visita = service.listId(id);
        if (visita == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe visita con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        VisitaDTO dto = m.map(visita, VisitaDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Visita visita = service.listId(id);
        if (visita == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe visita con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Visita con ID " + id + " eliminada correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody VisitaDTO dto) {
        ModelMapper m = new ModelMapper();
        Visita visita = m.map(dto, Visita.class);
        Visita existente = service.listId(visita.getIdVisita());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe visita con ID: " + visita.getIdVisita());
        }
        service.edit(visita);
        return ResponseEntity.ok("Visita con ID " + visita.getIdVisita() + " modificada correctamente.");
    }
}
