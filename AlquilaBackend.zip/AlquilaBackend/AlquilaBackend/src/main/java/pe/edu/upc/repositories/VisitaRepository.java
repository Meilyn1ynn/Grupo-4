package pe.edu.upc.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.Visita;

import java.util.List;

@Repository
public interface VisitaRepository extends JpaRepository<Visita, Integer> {

    // Listar visitas por inquilino
    @Query("SELECT v FROM Visita v WHERE v.inquilino.idUsuario = :idInquilino")
    List<Visita> listarPorInquilino(@Param("idInquilino") Integer idInquilino);

    // Listar visitas por propietario
    @Query("SELECT v FROM Visita v WHERE v.propiedad.usuario.idUsuario = :idPropietario")
    List<Visita> listarPorPropietario(@Param("idPropietario") Integer idPropietario);

    // Buscar visitas por estado (pendiente, confirmada, cancelada)
    List<Visita> findByEstado(String estado);
}