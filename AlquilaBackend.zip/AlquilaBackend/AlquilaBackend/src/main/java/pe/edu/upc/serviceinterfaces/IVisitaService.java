package pe.edu.upc.serviceinterfaces;

import pe.edu.upc.entities.Visita;
import java.util.List;

public interface IVisitaService {
    public List<Visita> list();
    public void insert(Visita visita);
    public Visita listId(int id);
    public void delete(int id);
    public void edit(Visita visita);
    public List<Visita> visitasPorUsuario(int idUsuario);

}
