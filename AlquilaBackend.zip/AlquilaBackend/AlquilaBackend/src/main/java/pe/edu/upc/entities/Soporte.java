package pe.edu.upc.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "Soporte")
public class Soporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "So_id")
    private int idSoporte;

    @ManyToOne
    @JoinColumn(name = "Us_id", nullable = false)
    private Usuario usuario;

    @Column(name = "So_mensaje", nullable = false)
    private String mensaje;

    @Column(name = "So_estado")
    private String estado;

    @Column(name = "So_fecha")
    private Date fecha;

    public Soporte(int idSoporte, Usuario usuario, String mensaje, String estado, Date fecha) {
        this.idSoporte = idSoporte;
        this.usuario = usuario;
        this.mensaje = mensaje;
        this.estado = estado;
        this.fecha = fecha;
    }

    public int getIdSoporte() {
        return idSoporte;
    }

    public void setIdSoporte(int idSoporte) {
        this.idSoporte = idSoporte;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
