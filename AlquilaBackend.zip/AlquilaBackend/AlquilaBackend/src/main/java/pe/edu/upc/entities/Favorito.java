package pe.edu.upc.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "Favorito", uniqueConstraints = @UniqueConstraint(columnNames = {"Us_id", "Pr_id"}))
public class Favorito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Fa_id")
    private int idFavorito;

    @ManyToOne
    @JoinColumn(name = "Us_id", nullable = false)
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "Pr_id", nullable = false)
    private Propiedad propiedad;

    @Column(name = "Fa_fecha")
    private Date fecha;

    public Favorito(int idFavorito, Usuario usuario, Propiedad propiedad, Date fecha) {
        this.idFavorito = idFavorito;
        this.usuario = usuario;
        this.propiedad = propiedad;
        this.fecha = fecha;
    }

    public int getIdFavorito() {
        return idFavorito;
    }

    public void setIdFavorito(int idFavorito) {
        this.idFavorito = idFavorito;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
