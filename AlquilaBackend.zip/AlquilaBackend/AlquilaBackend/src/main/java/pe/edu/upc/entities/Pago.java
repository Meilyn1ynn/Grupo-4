package pe.edu.upc.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "Pago")
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Pa_id")
    private int idPago;

    @ManyToOne
    @JoinColumn(name = "Con_id", nullable = false)
    private Contrato contrato;

    @Column(name = "Pa_monto", nullable = false)
    private Double monto;

    @Column(name = "Pa_fecha", nullable = false)
    private Date fecha;

    @Column(name = "Pa_metodo", nullable = false)
    private String metodo;

    @Column(name = "Pa_estado")
    private String estado;

    public Pago(int idPago, Contrato contrato, Double monto, Date fecha, String metodo, String estado) {
        this.idPago = idPago;
        this.contrato = contrato;
        this.monto = monto;
        this.fecha = fecha;
        this.metodo = metodo;
        this.estado = estado;
    }

    public int getIdPago() {
        return idPago;
    }

    public void setIdPago(int idPago) {
        this.idPago = idPago;
    }

    public Contrato getContrato() {
        return contrato;
    }

    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
