package pe.edu.upc.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.entities.Pago;

import java.util.List;

@Repository
public interface PagoRepository extends JpaRepository<Pago, Integer> {

    // Listar pagos por contrato
    @Query("SELECT p FROM Pago p WHERE p.contrato.idContrato = :idContrato")
    List<Pago> pagosPorContrato(@Param("idContrato") Integer idContrato);

    // Buscar pagos por estado (pendiente, realizado, rechazado)
    List<Pago> findByEstado(String estado);

    // Historial de pagos por propietario
    @Query("SELECT p FROM Pago p WHERE p.contrato.propietario.idUsuario = :idPropietario")
    List<Pago> historialPagosPropietario(@Param("idPropietario") Integer idPropietario);

    // Historial de pagos por inquilino
    @Query("SELECT p FROM Pago p WHERE p.contrato.inquilino.idUsuario = :idInquilino")
    List<Pago> historialPagosInquilino(@Param("idInquilino") Integer idInquilino);
}
