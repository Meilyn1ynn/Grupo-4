package pe.edu.upc.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.dtos.ReseñaDTO;
import pe.edu.upc.entities.Reseña;
import pe.edu.upc.serviceinterfaces.IReseñaService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/resenas")
public class ReseñaController {

    @Autowired
    private IReseñaService service;

    @GetMapping
    public List<ReseñaDTO> listar() {
        return service.list().stream().map(r -> {
            ModelMapper m = new ModelMapper();
            return m.map(r, ReseñaDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody ReseñaDTO dto) {
        ModelMapper m = new ModelMapper();
        Reseña resena = m.map(dto, Reseña.class);
        service.insert(resena);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Reseña resena = service.listId(id);
        if (resena == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe reseña con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        ReseñaDTO dto = m.map(resena, ReseñaDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Reseña resena = service.listId(id);
        if (resena == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe reseña con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Reseña con ID " + id + " eliminada correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody ReseñaDTO dto) {
        ModelMapper m = new ModelMapper();
        Reseña resena = m.map(dto, Reseña.class);
        Reseña existente = service.listId(resena.getIdReseña());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe reseña con ID: " + resena.getIdReseña());
        }
        service.edit(resena);
        return ResponseEntity.ok("Reseña con ID " + resena.getIdReseña() + " modificada correctamente.");
    }
}