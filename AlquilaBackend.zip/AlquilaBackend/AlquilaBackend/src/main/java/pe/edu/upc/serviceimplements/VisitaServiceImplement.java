package pe.edu.upc.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.entities.Visita;
import pe.edu.upc.repositories.VisitaRepository;
import pe.edu.upc.serviceinterfaces.IVisitaService;

import java.util.List;

@Service
public class VisitaServiceImplement implements IVisitaService {

    @Autowired
    private VisitaRepository repository;

    @Override
    public List<Visita> list() {
        return repository.findAll();
    }

    @Override
    public void insert(Visita visita) {
        repository.save(visita);
    }

    @Override
    public Visita listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(Visita visita) {
        repository.save(visita);
    }

    @Override
    public List<Visita> visitasPorUsuario(int idUsuario) {
        return repository.listarPorInquilino(idUsuario);
    }
}