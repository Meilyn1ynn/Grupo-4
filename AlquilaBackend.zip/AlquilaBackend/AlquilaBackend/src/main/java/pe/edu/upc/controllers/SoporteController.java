package pe.edu.upc.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.dtos.SoporteDTO;
import pe.edu.upc.entities.Soporte;
import pe.edu.upc.serviceinterfaces.ISoporteService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/soporte")
public class SoporteController {

    @Autowired
    private ISoporteService service;

    @GetMapping
    public List<SoporteDTO> listar() {
        return service.list().stream().map(s -> {
            ModelMapper m = new ModelMapper();
            return m.map(s, SoporteDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody SoporteDTO dto) {
        ModelMapper m = new ModelMapper();
        Soporte s = m.map(dto, Soporte.class);
        service.insert(s);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Soporte s = service.listId(id);
        if (s == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe ticket de soporte con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        SoporteDTO dto = m.map(s, SoporteDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Soporte s = service.listId(id);
        if (s == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe ticket de soporte con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Ticket con ID " + id + " eliminado correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody SoporteDTO dto) {
        ModelMapper m = new ModelMapper();
        Soporte s = m.map(dto, Soporte.class);
        Soporte existente = service.listId(s.getIdSoporte());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe ticket con ID: " + s.getIdSoporte());
        }
        service.edit(s);
        return ResponseEntity.ok("Ticket con ID " + s.getIdSoporte() + " modificado correctamente.");
    }
}