package pe.edu.upc.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.entities.ContratoClausula;
import pe.edu.upc.repositories.ContratoClausulaRepository;
import pe.edu.upc.serviceinterfaces.IContratoClausulaService;

import java.util.List;

@Service
public class ContratoClausulaServiceImplement implements IContratoClausulaService {
    @Autowired
    private ContratoClausulaRepository contratoClausulaRepository;

    @Override
    public List<ContratoClausula> list() {
        return List.of();
    }

    @Override
    public void insert(ContratoClausula clausula) {

    }

    @Override
    public ContratoClausula listId(int id) {
        return null;
    }

    @Override
    public void delete(int id) {

    }

    @Override
    public void edit(ContratoClausula clausula) {

    }

    @Override
    public List<ContratoClausula> clausulasPorContrato(int idContrato) {
        return List.of();
    }
}
