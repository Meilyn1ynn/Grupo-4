package pe.edu.upc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEcoGastoApplicationTests {

    @Test
    void contextLoads() {
    }

}
