# Sistema de Seguridad AlquilaYa

## Descripción General

Este sistema de seguridad implementa autenticación y autorización basada en JWT (JSON Web Tokens) para la aplicación AlquilaYa, una plataforma de alquiler de propiedades.

## Roles del Sistema

El sistema cuenta con **3 roles principales**:

### 1. ADMIN
- **Descripción**: Administradores del sistema con acceso completo
- **Permisos**:
  - Gestión completa de usuarios y roles
  - Acceso a reportes y estadísticas
  - Gestión de todas las propiedades
  - Moderación de contenido
  - Configuración del sistema

### 2. PROPIETARIO
- **Descripción**: Usuarios que pueden publicar propiedades para alquilar
- **Permisos**:
  - Publicar y gestionar sus propiedades
  - Ver y responder solicitudes de alquiler
  - Gestionar contratos como arrendador
  - Gestionar visitas a sus propiedades
  - Ver reseñas de sus propiedades

### 3. USUARIO
- **Descripción**: Usuarios que pueden buscar y alquilar propiedades (inquilinos)
- **Permisos**:
  - Buscar y explorar propiedades
  - Solicitar alquileres
  - Gestionar contratos como arrendatario
  - Añadir propiedades a favoritos
  - Programar visitas
  - Escribir reseñas

## Arquitectura de Seguridad

### Entidades Principales

#### User (auth_users)
```java
- id: Long (Primary Key)
- username: String (Unique)
- password: String (Encrypted)
- nombre: String
- apellido: String
- correo: String (Unique)
- dni: String (Unique)
- telefono: String
- enabled: Boolean
- roles: Set<Role> (ManyToMany)
```

#### Role (roles)
```java
- id: Long (Primary Key)
- name: String (Unique) // ADMIN, PROPIETARIO, USUARIO
```

### Endpoints de Autenticación

#### POST /api/auth/register
Registro de nuevos usuarios.

**Request Body:**
```json
{
  "username": "string",
  "password": "string",
  "nombre": "string",
  "apellido": "string",
  "correo": "string",
  "dni": "string",
  "telefono": "string",
  "rol": "USUARIO" // o "PROPIETARIO"
}
```

#### POST /api/auth/login
Autenticación de usuarios existentes.

**Request Body:**
```json
{
  "username": "string",
  "password": "string"
}
```

**Response:**
```json
{
  "jwt": "eyJhbGciOiJIUzUxMiJ9...",
  "username": "string",
  "roles": ["ROLE_USUARIO"]
}
```

### Endpoints de Prueba

#### GET /api/test/public
- **Acceso**: Público (sin autenticación)
- **Descripción**: Endpoint de prueba público

#### GET /api/test/admin
- **Acceso**: Solo ADMIN
- **Descripción**: Endpoint exclusivo para administradores

#### GET /api/test/usuario
- **Acceso**: USUARIO y ADMIN
- **Descripción**: Endpoint para usuarios regulares

#### GET /api/test/propietario
- **Acceso**: PROPIETARIO y ADMIN
- **Descripción**: Endpoint para propietarios

#### GET /api/test/authenticated
- **Acceso**: Cualquier usuario autenticado
- **Descripción**: Endpoint para usuarios autenticados

## Configuración de Endpoints por Rol

### Endpoints Públicos (Sin autenticación)
- `/api/auth/login`
- `/api/auth/register`
- `/api/test/public`
- `/swagger-ui/**`
- `/v3/api-docs/**`

### Endpoints de Administrador (ADMIN)
- `/api/admin/**`
- `/api/usuarios/admin/**`
- `/api/reportes/**`

### Endpoints de Propietario (PROPIETARIO + ADMIN)
- `/api/propiedades/create`
- `/api/propiedades/mis-propiedades`
- `/api/propiedades/{id}/edit`
- `/api/propiedades/{id}/delete`
- `/api/contratos/propietario/**`

### Endpoints de Usuario (USUARIO + PROPIETARIO + ADMIN)
- `/api/propiedades/search`
- `/api/propiedades/list`
- `/api/propiedades/{id}/view`
- `/api/contratos/solicitar` (Solo USUARIO + ADMIN)
- `/api/contratos/mis-contratos`
- `/api/favoritos/**` (Solo USUARIO + ADMIN)
- `/api/visitas/**`
- `/api/reseñas/**`
- `/api/pagos/**`
- `/api/notificaciones/**`
- `/api/soporte/**`

## Configuración JWT

### Propiedades en application.properties
```properties
# JWT Configuration
jwt.secret=alquilaya-secret-key-for-jwt-tokens-2024-super-secure-key
jwt.expiration=86400000 # 24 horas en milisegundos
```

### Características del Token
- **Algoritmo**: HS512
- **Duración**: 24 horas por defecto
- **Información incluida**: username, roles, fecha de emisión y expiración

## Uso del JWT

### En el Frontend
1. **Login**: Enviar credenciales a `/api/auth/login`
2. **Recibir Token**: Guardar el JWT del response
3. **Requests**: Incluir el token en el header `Authorization: Bearer <token>`

### Ejemplo de Header
```
Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ1c3VhcmlvMSIsInJvbGVzIjpbeyJhdXRob3JpdHkiOiJST0xFX1VTVUFSSU8ifV0sImlhdCI6MTcyODE2MTIwMCwiZXhwIjoxNzI4MjQ3NjAwfQ.xyz...
```

## Inicialización de Roles

El sistema incluye un `RoleDataSeeder` que automáticamente crea los 3 roles básicos al iniciar la aplicación:

```java
@Component
public class RoleDataSeeder implements CommandLineRunner {
    // Crea USUARIO, PROPIETARIO y ADMIN si no existen
}
```

## Seguridad de Contraseñas

- Las contraseñas se encriptan usando **BCrypt**
- Nunca se almacenan en texto plano
- Se validan durante la autenticación

## CORS Configuration

El sistema está configurado para permitir peticiones desde cualquier origen en desarrollo:

```java
@Bean
public CorsFilter corsFilter() {
    // Configuración CORS para desarrollo
    config.addAllowedOriginPattern("*");
    config.addAllowedMethod("*");
    config.addAllowedHeader("*");
}
```

## Próximos Pasos Recomendados

1. **Integrar con entidades existentes**: Conectar el sistema de seguridad con las entidades Usuario existentes
2. **Implementar endpoints específicos**: Crear controladores para propiedades, contratos, etc.
3. **Añadir validaciones**: Validaciones de entrada más robustas
4. **Refresh Tokens**: Implementar tokens de renovación
5. **Auditoría**: Agregar logs de acceso y actividad
6. **Roles dinámicos**: Permitir asignación de roles desde interfaz admin

## Estructura de Archivos

```
src/main/java/pe/edu/upc/apisanisidro/security/
├── config/
│   ├── RoleDataSeeder.java
│   └── SecurityConfig.java
├── controllers/
│   ├── AuthController.java
│   └── TestController.java
├── dtos/
│   ├── AuthRequestDTO.java
│   ├── AuthResponseDTO.java
│   └── RegistroRequestDTO.java
├── entities/
│   ├── Role.java
│   └── User.java
├── filters/
│   └── JwtRequestFilter.java
├── repositories/
│   ├── RoleRepository.java
│   └── UserRepository.java
├── services/
│   ├── CustomUserDetailsService.java
│   └── UserService.java
└── util/
    └── JwtUtil.java
```

---

**Desarrollado para AlquilaYa - Sistema de Alquiler de Propiedades**