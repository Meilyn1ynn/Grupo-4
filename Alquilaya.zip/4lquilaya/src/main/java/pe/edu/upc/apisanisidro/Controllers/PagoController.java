package pe.edu.upc.apisanisidro.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.apisanisidro.DTOs.PagoDTO;
import pe.edu.upc.apisanisidro.Entities.Pago;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IPagoService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/pagos")
public class PagoController {

    @Autowired
    private IPagoService service;

    @GetMapping
    public List<PagoDTO> listar() {
        return service.list().stream().map(p -> {
            ModelMapper m = new ModelMapper();
            return m.map(p, PagoDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody PagoDTO dto) {
        ModelMapper m = new ModelMapper();
        Pago pago = m.map(dto, Pago.class);
        service.insert(pago);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Pago pago = service.listId(id);
        if (pago == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe pago con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        PagoDTO dto = m.map(pago, PagoDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Pago pago = service.listId(id);
        if (pago == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe pago con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Pago con ID " + id + " eliminado correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody PagoDTO dto) {
        ModelMapper m = new ModelMapper();
        Pago pago = m.map(dto, Pago.class);
        Pago existente = service.listId(pago.getIdPago());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe pago con ID: " + pago.getIdPago());
        }
        service.edit(pago);
        return ResponseEntity.ok("Pago con ID " + pago.getIdPago() + " modificado correctamente.");
    }
}