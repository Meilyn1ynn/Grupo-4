package pe.edu.upc.apisanisidro.ServicesInterfaces;

import pe.edu.upc.apisanisidro.Entities.Notificacion;

import java.util.List;

public interface INotificacionService {
    public List<Notificacion> list();
    public void insert(Notificacion notificacion);
    public Notificacion listId(int id);
    public void delete(int id);
    public void edit(Notificacion notificacion);
    public List<Notificacion> notificacionesPorUsuario(int idUsuario);
}