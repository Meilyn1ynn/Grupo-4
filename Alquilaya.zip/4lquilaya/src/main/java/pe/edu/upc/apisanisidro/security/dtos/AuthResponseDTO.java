package pe.edu.upc.apisanisidro.security.dtos;

import java.util.Set;

public class AuthResponseDTO {
    private String jwt;
    private String username;
    private Set<String> roles;

    public AuthResponseDTO() {}

    public AuthResponseDTO(String jwt, String username, Set<String> roles) {
        this.jwt = jwt;
        this.username = username;
        this.roles = roles;
    }

    public String getJwt() {
        return jwt;
    }

    public void setJwt(String jwt) {
        this.jwt = jwt;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Set<String> getRoles() {
        return roles;
    }

    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }
}