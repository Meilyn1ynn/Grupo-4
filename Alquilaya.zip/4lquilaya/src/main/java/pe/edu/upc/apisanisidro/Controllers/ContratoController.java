package pe.edu.upc.apisanisidro.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.apisanisidro.DTOs.ContratoDTO;
import pe.edu.upc.apisanisidro.Entities.Contrato;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IContratoService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/contratos")
public class ContratoController {

    @Autowired
    private IContratoService service;

    @GetMapping
    public List<ContratoDTO> listar() {
        return service.list().stream().map(c -> {
            ModelMapper m = new ModelMapper();
            return m.map(c, ContratoDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody ContratoDTO dto) {
        ModelMapper m = new ModelMapper();
        Contrato contrato = m.map(dto, Contrato.class);
        service.insert(contrato);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Contrato contrato = service.listId(id);
        if (contrato == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe contrato con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        ContratoDTO dto = m.map(contrato, ContratoDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Contrato contrato = service.listId(id);
        if (contrato == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe contrato con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Contrato con ID " + id + " eliminado correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody ContratoDTO dto) {
        ModelMapper m = new ModelMapper();
        Contrato contrato = m.map(dto, Contrato.class);
        Contrato existente = service.listId(contrato.getIdContrato());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe contrato con ID: " + contrato.getIdContrato());
        }
        service.edit(contrato);
        return ResponseEntity.ok("Contrato con ID " + contrato.getIdContrato() + " modificado correctamente.");
    }
}