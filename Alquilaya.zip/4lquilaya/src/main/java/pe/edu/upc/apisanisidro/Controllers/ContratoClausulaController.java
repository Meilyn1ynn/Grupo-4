package pe.edu.upc.apisanisidro.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.apisanisidro.DTOs.ContratoClausulaDTO;
import pe.edu.upc.apisanisidro.Entities.ContratoClausula;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IContratoClausulaService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/contratos/clausulas")
public class ContratoClausulaController {

    @Autowired
    private IContratoClausulaService service;

    @GetMapping
    public List<ContratoClausulaDTO> listar() {
        return service.list().stream().map(c -> {
            ModelMapper m = new ModelMapper();
            return m.map(c, ContratoClausulaDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody ContratoClausulaDTO dto) {
        ModelMapper m = new ModelMapper();
        ContratoClausula clausula = m.map(dto, ContratoClausula.class);
        service.insert(clausula);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        ContratoClausula clausula = service.listId(id);
        if (clausula == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe cláusula con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        ContratoClausulaDTO dto = m.map(clausula, ContratoClausulaDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        ContratoClausula clausula = service.listId(id);
        if (clausula == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe cláusula con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Cláusula con ID " + id + " eliminada correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody ContratoClausulaDTO dto) {
        ModelMapper m = new ModelMapper();
        ContratoClausula clausula = m.map(dto, ContratoClausula.class);
        ContratoClausula existente = service.listId(clausula.getIdClausula());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe cláusula con ID: " + clausula.getIdClausula());
        }
        service.edit(clausula);
        return ResponseEntity.ok("Cláusula con ID " + clausula.getIdClausula() + " modificada correctamente.");
    }
}