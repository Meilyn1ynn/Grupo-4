package pe.edu.upc.apisanisidro.ServicesImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.apisanisidro.Entities.Reseña;
import pe.edu.upc.apisanisidro.Repository.ReseñaRepository;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IReseñaService;

import java.util.List;

@Service
public class ReseñaServiceImplement implements IReseñaService {

    @Autowired
    private ReseñaRepository repository;

    @Override
    public List<Reseña> list() {
        return repository.findAll();
    }

    @Override
    public void insert(Reseña reseña) {
        repository.save(reseña);
    }

    @Override
    public Reseña listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(Reseña reseña) {
        repository.save(reseña);
    }

    @Override
    public List<Reseña> reseñasPorUsuario(int idUsuario) {
        return repository.reseñasRecibidas(idUsuario);
    }
}