package pe.edu.upc.apisanisidro.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import pe.edu.upc.apisanisidro.security.filters.JwtRequestFilter;
import pe.edu.upc.apisanisidro.security.services.CustomUserDetailsService;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final JwtRequestFilter jwtRequestFilter;

    public SecurityConfig(CustomUserDetailsService userDetailsService, JwtRequestFilter jwtRequestFilter) {
        this.userDetailsService = userDetailsService;
        this.jwtRequestFilter = jwtRequestFilter;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                        // Endpoints públicos (sin autenticación)
                        .requestMatchers("/api/security/login", "/api/security/register").permitAll()
                        .requestMatchers("/api/security/test").permitAll()
                        .requestMatchers("/api/test/public").permitAll()
                        .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
                        
                        // Endpoints para administradores
                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        .requestMatchers("/api/usuarios/admin/**").hasRole("ADMIN")
                        .requestMatchers("/api/reportes/**").hasRole("ADMIN")
                        
                        // Endpoints para propietarios (pueden gestionar sus propiedades)
                        .requestMatchers("/api/propiedades/create").hasAnyRole("PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/propiedades/mis-propiedades").hasAnyRole("PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/propiedades/{id}/edit").hasAnyRole("PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/propiedades/{id}/delete").hasAnyRole("PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/contratos/propietario/**").hasAnyRole("PROPIETARIO", "ADMIN")
                        
                        // Endpoints para usuarios (pueden arrendar, buscar propiedades)
                        .requestMatchers("/api/propiedades/search", "/api/propiedades/list").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/propiedades/{id}/view").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/contratos/solicitar").hasAnyRole("USUARIO", "ADMIN")
                        .requestMatchers("/api/contratos/mis-contratos").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/favoritos/**").hasAnyRole("USUARIO", "ADMIN")
                        .requestMatchers("/api/visitas/**").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/reseñas/**").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/pagos/**").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/notificaciones/**").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        .requestMatchers("/api/soporte/**").hasAnyRole("USUARIO", "PROPIETARIO", "ADMIN")
                        
                        // Cualquier otra petición requiere autenticación
                        .anyRequest().authenticated()
                )
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                );

        // Añadir filtros en orden: CORS -> JWT -> Authentication
        http.addFilterBefore(corsFilter(), UsernamePasswordAuthenticationFilter.class);
        http.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("*"); // Permitir cualquier origen en desarrollo
        config.addAllowedMethod("*"); // Permitir todos los métodos HTTP
        config.addAllowedHeader("*"); // Permitir todos los headers
        config.addExposedHeader("Authorization");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }
}
