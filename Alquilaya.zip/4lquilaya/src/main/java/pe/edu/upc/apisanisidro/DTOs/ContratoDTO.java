package pe.edu.upc.apisanisidro.DTOs;

import java.time.LocalDate;
import java.util.List;

public class ContratoDTO {
    private int idContrato;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private String estado;
    private int idPropiedad;
    private int idInquilino;
    private int idPropietario;
    private List<String> clausulas;

    public int getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(int idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public int getIdInquilino() {
        return idInquilino;
    }

    public void setIdInquilino(int idInquilino) {
        this.idInquilino = idInquilino;
    }

    public int getIdPropietario() {
        return idPropietario;
    }

    public void setIdPropietario(int idPropietario) {
        this.idPropietario = idPropietario;
    }

    public List<String> getClausulas() {
        return clausulas;
    }

    public void setClausulas(List<String> clausulas) {
        this.clausulas = clausulas;
    }
}
