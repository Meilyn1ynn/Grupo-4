package pe.edu.upc.apisanisidro.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import pe.edu.upc.apisanisidro.security.entities.Role;
import pe.edu.upc.apisanisidro.security.repositories.RoleRepository;

@Component
public class RoleDataSeeder implements CommandLineRunner {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public void run(String... args) {
        // Crear roles básicos para AlquilaYa si no existen
        
        // Rol para usuarios que pueden arrendar/alquilar propiedades (inquilinos)
        if (roleRepository.findByName("USUARIO").isEmpty()) {
            Role usuarioRole = new Role();
            usuarioRole.setName("USUARIO");
            roleRepository.save(usuarioRole);
        }

        // Rol para propietarios que pueden publicar propiedades para alquilar
        if (roleRepository.findByName("PROPIETARIO").isEmpty()) {
            Role propietarioRole = new Role();
            propietarioRole.setName("PROPIETARIO");
            roleRepository.save(propietarioRole);
        }

        // Rol para administradores del sistema
        if (roleRepository.findByName("ADMIN").isEmpty()) {
            Role adminRole = new Role();
            adminRole.setName("ADMIN");
            roleRepository.save(adminRole);
        }
    }
}