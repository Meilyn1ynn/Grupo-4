package pe.edu.upc.apisanisidro.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.apisanisidro.Entities.Contrato;

@Repository
public interface ContratoRepository extends JpaRepository<Contrato, Integer> {

    // Buscar contratos activos por propietario
    @Query("SELECT c FROM Contrato c WHERE c.propietario.idUsuario = :idPropietario AND c.estado = 'Activo'")
    List<Contrato> contratosActivosPorPropietario(@Param("idPropietario") Integer idPropietario);

    // Buscar contratos activos por inquilino
    @Query("SELECT c FROM Contrato c WHERE c.inquilino.idUsuario = :idInquilino AND c.estado = 'Activo'")
    List<Contrato> contratosActivosPorInquilino(@Param("idInquilino") Integer idInquilino);

    // Buscar contratos que vencen pronto (próximos 30 días) - Consulta nativa PostgreSQL
    @Query(value = "SELECT * FROM contrato c WHERE c.fecha_fin BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days' AND c.estado = 'Activo'", nativeQuery = true)
    List<Contrato> contratosPorVencer();

    // Buscar contratos por usuario (tanto como propietario como inquilino)
    @Query("SELECT c FROM Contrato c WHERE c.propietario.idUsuario = :idUsuario OR c.inquilino.idUsuario = :idUsuario")
    List<Contrato> contratosPorUsuario(@Param("idUsuario") int idUsuario);
}
