package pe.edu.upc.apisanisidro.security.controllers;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.edu.upc.apisanisidro.security.dtos.AuthRequestDTO;
import pe.edu.upc.apisanisidro.security.dtos.AuthResponseDTO;
import pe.edu.upc.apisanisidro.security.dtos.RegistroRequestDTO;
import pe.edu.upc.apisanisidro.security.entities.Role;
import pe.edu.upc.apisanisidro.security.entities.User;
import pe.edu.upc.apisanisidro.security.repositories.RoleRepository;
import pe.edu.upc.apisanisidro.security.repositories.UserRepository;
import pe.edu.upc.apisanisidro.security.services.CustomUserDetailsService;
import pe.edu.upc.apisanisidro.security.util.JwtUtil;

@CrossOrigin(originPatterns = "*", allowedHeaders = "*", exposedHeaders = "Authorization")
@RestController
@RequestMapping("/api/security")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final CustomUserDetailsService userDetailsService;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthController(AuthenticationManager authenticationManager, JwtUtil jwtUtil, 
                         CustomUserDetailsService userDetailsService, UserRepository userRepository, 
                         RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.userDetailsService = userDetailsService;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Endpoint para autenticación de usuarios
     */
    @PostMapping({"/authenticate", "/login"})
    public ResponseEntity<?> login(@RequestBody AuthRequestDTO authRequest) throws Exception {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
            );

            final UserDetails userDetails = userDetailsService.loadUserByUsername(authRequest.getUsername());
            final String token = jwtUtil.generateToken(userDetails);

            Set<String> roles = userDetails.getAuthorities()
                    .stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toSet());

            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.set("Authorization", "Bearer " + token);
            
            AuthResponseDTO authResponseDTO = new AuthResponseDTO(token, userDetails.getUsername(), roles);
            
            return ResponseEntity.ok().headers(responseHeaders).body(authResponseDTO);
        } catch (Exception e) {
            System.out.println("Error durante login: " + e.getMessage());
            e.printStackTrace();
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Error de autenticación: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    /**
     * Endpoint para registro de nuevos usuarios
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> register(@RequestBody RegistroRequestDTO registroRequest) {
        Map<String, String> response = new HashMap<>();
        
        try {
            // Validaciones
            if (userRepository.existsByUsername(registroRequest.getUsername())) {
                response.put("error", "El nombre de usuario ya existe");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }
            
            if (userRepository.existsByCorreo(registroRequest.getCorreo())) {
                response.put("error", "El correo ya está registrado");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            if (userRepository.existsByDni(registroRequest.getDni())) {
                response.put("error", "El DNI ya está registrado");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }
            
            // Crear nuevo usuario
            User nuevoUsuario = new User();
            nuevoUsuario.setUsername(registroRequest.getUsername());
            nuevoUsuario.setPassword(passwordEncoder.encode(registroRequest.getPassword()));
            nuevoUsuario.setNombre(registroRequest.getNombre());
            nuevoUsuario.setApellido(registroRequest.getApellido());
            nuevoUsuario.setCorreo(registroRequest.getCorreo());
            nuevoUsuario.setDni(registroRequest.getDni());
            nuevoUsuario.setTelefono(registroRequest.getTelefono());
            nuevoUsuario.setEnabled(true);
            
            // Determinar rol basado en la solicitud (por defecto USUARIO)
            String rolNombre = registroRequest.getRol();
            if (rolNombre == null || rolNombre.isEmpty()) {
                rolNombre = "USUARIO";
            }
            
            // Validar que el rol sea válido
            if (!rolNombre.equals("USUARIO") && !rolNombre.equals("PROPIETARIO")) {
                rolNombre = "USUARIO";
            }
            
            Role role = roleRepository.findByName(rolNombre)
                .orElseThrow(() -> new RuntimeException("Error: Rol no encontrado"));
            nuevoUsuario.getRoles().add(role);
            
            // Guardar usuario
            userRepository.save(nuevoUsuario);
            
            response.put("message", "Usuario registrado exitosamente con rol: " + rolNombre);
            response.put("username", nuevoUsuario.getUsername());
            response.put("rol", rolNombre);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
            
        } catch (Exception e) {
            response.put("error", "Error interno del servidor: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}


