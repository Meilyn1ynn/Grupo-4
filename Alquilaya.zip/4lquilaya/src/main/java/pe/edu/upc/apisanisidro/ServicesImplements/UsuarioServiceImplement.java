package pe.edu.upc.apisanisidro.ServicesImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.apisanisidro.Entities.Usuario;
import pe.edu.upc.apisanisidro.Repository.UsuarioRepository;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IUsuarioService;

import java.util.List;

@Service
public class UsuarioServiceImplement implements IUsuarioService {

    @Autowired
    private UsuarioRepository uR;

    @Override
    public List<Usuario> list() {
        return uR.findAll();
    }

    @Override
    public void insert(Usuario usuario) {
        uR.save(usuario);
    }

    @Override
    public Usuario listId(int id) {
        return uR.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        uR.deleteById(id);
    }

    @Override
    public void edit(Usuario usuario) {
        uR.save(usuario);
    }

    @Override
    public List<Usuario> buscarPorNombre(String nombre) {
        return uR.buscarPorNombre(nombre);
    }

    @Override
    public List<Object[]> cantidadUsuariosPorRol() {
        // Esta funcionalidad ahora se maneja desde el security package
        // Retornamos una lista vacía para mantener compatibilidad
        return List.of();
    }

    @Override
    public List<Usuario> buscarService(String nombre) {
        return buscarPorNombre(nombre);
    }
}