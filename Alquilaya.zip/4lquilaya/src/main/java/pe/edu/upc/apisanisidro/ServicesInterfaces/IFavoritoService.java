package pe.edu.upc.apisanisidro.ServicesInterfaces;

import pe.edu.upc.apisanisidro.Entities.Favorito;

import java.util.List;

public interface IFavoritoService {
    public List<Favorito> list();
    public void insert(Favorito favorito);
    public Favorito listId(int id);
    public void delete(int id);
    public void edit(Favorito favorito);
    public List<Favorito> favoritosPorUsuario(int idUsuario);
}