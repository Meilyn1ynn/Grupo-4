package pe.edu.upc.apisanisidro.Entities;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table(name = "Propiedad")
public class Propiedad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Pr_id")
    private int idPropiedad;

    @Column(name = "Pr_titulo", nullable = false)
    private String titulo;

    @Column(name = "Pr_descripcion")
    private String descripcion;

    @Column(name = "Pr_direccion")
    private String direccion;

    @Column(name = "Pr_distrito")
    private String distrito;

    @Column(name = "Pr_precio", nullable = false)
    private Double precio;

    @Column(name = "Pr_habitaciones")
    private Integer habitaciones;

    @Column(name = "Pr_fecha_publicacion")
    private Date fechaPublicacion;

    @ManyToOne
    @JoinColumn(name = "Us_id", nullable = false)
    private Usuario usuario;

    @OneToMany(mappedBy = "propiedad", cascade = CascadeType.ALL)
    private List<PropiedadFoto> fotos = new ArrayList<>();

    // Constructor vacío requerido por JPA
    public Propiedad() {}

    public Propiedad(int idPropiedad, String titulo, String descripcion, String direccion, String distrito, Double precio, Integer habitaciones, Date fechaPublicacion, Usuario usuario, List<PropiedadFoto> fotos) {
        this.idPropiedad = idPropiedad;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.direccion = direccion;
        this.distrito = distrito;
        this.precio = precio;
        this.habitaciones = habitaciones;
        this.fechaPublicacion = fechaPublicacion;
        this.usuario = usuario;
        this.fotos = fotos;
    }

    public int getIdPropiedad() {
        return idPropiedad;
    }

    public void setIdPropiedad(int idPropiedad) {
        this.idPropiedad = idPropiedad;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Integer getHabitaciones() {
        return habitaciones;
    }

    public void setHabitaciones(Integer habitaciones) {
        this.habitaciones = habitaciones;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<PropiedadFoto> getFotos() {
        return fotos;
    }

    public void setFotos(List<PropiedadFoto> fotos) {
        this.fotos = fotos;
    }
}