package pe.edu.upc.apisanisidro.Controllers;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.apisanisidro.DTOs.UsuarioDTO;
import pe.edu.upc.apisanisidro.Entities.Usuario;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IUsuarioService;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private IUsuarioService service;

    @GetMapping
    public List<UsuarioDTO> listar() {
        return service.list().stream().map(u -> {
            ModelMapper m = new ModelMapper();
            return m.map(u, UsuarioDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<String> registrar(@RequestBody UsuarioDTO dto) {
        ModelMapper m = new ModelMapper();
        Usuario user = m.map(dto, Usuario.class);
        try {
            service.insert(user);
            return ResponseEntity.ok("Bienvenido a AlquilaYa");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Vuelva a intentarlo");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Usuario user = service.listId(id);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un usuario con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        UsuarioDTO dto = m.map(user, UsuarioDTO.class);
        return ResponseEntity.ok(dto);
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody UsuarioDTO dto) {
        ModelMapper m = new ModelMapper();
        Usuario u = m.map(dto, Usuario.class);
        Usuario existente = service.listId(u.getIdUsuario());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe un registro con el ID: " + u.getIdUsuario());
        }
        service.edit(u);
        return ResponseEntity.ok("Cambios guardados correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Usuario u = service.listId(id);
        if (u == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un usuario con el ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Usuario eliminado correctamente.");
    }

    @GetMapping("/buscar")
    public ResponseEntity<?> buscar(@RequestParam String nombre) {
        List<Usuario> lista = service.buscarService(nombre);
        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontraron usuarios: " + nombre);
        }
        List<UsuarioDTO> listaDTO = lista.stream().map(u -> {
            ModelMapper m = new ModelMapper();
            return m.map(u, UsuarioDTO.class);
        }).collect(Collectors.toList());
        return ResponseEntity.ok(listaDTO);
    }
}