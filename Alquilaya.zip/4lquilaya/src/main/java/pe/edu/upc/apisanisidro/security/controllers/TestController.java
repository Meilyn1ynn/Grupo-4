package pe.edu.upc.apisanisidro.security.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(originPatterns = "*", allowCredentials = "true", exposedHeaders = "Authorization")
@RestController
@RequestMapping("/api/test")
public class TestController {

    @GetMapping("/public")
    public Map<String, String> publicEndpoint() {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Este es un endpoint público, accesible sin autenticación");
        response.put("service", "AlquilaYa Security API");
        return response;
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public Map<String, String> adminEndpoint(Authentication authentication) {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Endpoint de administrador - Solo accesible por ADMIN");
        response.put("user", authentication.getName());
        response.put("roles", authentication.getAuthorities().toString());
        return response;
    }

    @GetMapping("/usuario")
    @PreAuthorize("hasAnyRole('USUARIO', 'ADMIN')")
    public Map<String, String> usuarioEndpoint(Authentication authentication) {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Endpoint para usuarios - Accesible por USUARIO y ADMIN");
        response.put("user", authentication.getName());
        response.put("roles", authentication.getAuthorities().toString());
        return response;
    }

    @GetMapping("/propietario")
    @PreAuthorize("hasAnyRole('PROPIETARIO', 'ADMIN')")
    public Map<String, String> propietarioEndpoint(Authentication authentication) {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Endpoint para propietarios - Accesible por PROPIETARIO y ADMIN");
        response.put("user", authentication.getName());
        response.put("roles", authentication.getAuthorities().toString());
        return response;
    }

    @GetMapping("/authenticated")
    @PreAuthorize("isAuthenticated()")
    public Map<String, String> authenticatedEndpoint(Authentication authentication) {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Endpoint autenticado - Accesible por cualquier usuario autenticado");
        response.put("user", authentication.getName());
        response.put("roles", authentication.getAuthorities().toString());
        return response;
    }
}
