package pe.edu.upc.apisanisidro.ServicesInterfaces;

import pe.edu.upc.apisanisidro.Entities.ContratoClausula;

import java.util.List;

public interface IContratoClausulaService {
    public List<ContratoClausula> list();
    public void insert(ContratoClausula clausula);
    public ContratoClausula listId(int id);
    public void delete(int id);
    public void edit(ContratoClausula clausula);
    public List<ContratoClausula> clausulasPorContrato(int idContrato);
}