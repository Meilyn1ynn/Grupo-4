package pe.edu.upc.apisanisidro.ServicesInterfaces;

import pe.edu.upc.apisanisidro.Entities.Propiedad;

import java.util.List;

public interface IPropiedadService {
    public List<Propiedad> list();
    public void insert(Propiedad p);
    public Propiedad listId(int id);
    public void delete(int id);
    public void edit(Propiedad p);
    public List<Propiedad> buscarPorDistrito(String distrito);
}