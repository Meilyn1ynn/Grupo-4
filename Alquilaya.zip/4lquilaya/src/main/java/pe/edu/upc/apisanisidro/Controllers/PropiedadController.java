package pe.edu.upc.apisanisidro.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.apisanisidro.DTOs.PropiedadDTO;
import pe.edu.upc.apisanisidro.Entities.Propiedad;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IPropiedadService;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/propiedades")
public class PropiedadController {

    @Autowired
    private IPropiedadService service;

    @GetMapping
    public List<PropiedadDTO> listar() {
        return service.list().stream().map(p -> {
            ModelMapper m = new ModelMapper();
            return m.map(p, PropiedadDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<String> publicar(@RequestBody PropiedadDTO dto) {
        ModelMapper m = new ModelMapper();
        Propiedad p = m.map(dto, Propiedad.class);
        try {
            service.insert(p);
            return ResponseEntity.ok("Propiedad publicada correctamente");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Complete todos los datos requeridos");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerPorId(@PathVariable("id") Integer id) {
        Propiedad prop = service.listId(id);
        if (prop == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe una propiedad con el ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        PropiedadDTO dto = m.map(prop, PropiedadDTO.class);
        return ResponseEntity.ok(dto);
    }

    @PutMapping
    public ResponseEntity<String> editar(@RequestBody PropiedadDTO dto) {
        ModelMapper m = new ModelMapper();
        Propiedad p = m.map(dto, Propiedad.class);
        Propiedad existente = service.listId(p.getIdPropiedad());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe una propiedad con el ID: " + p.getIdPropiedad());
        }
        service.edit(p);
        return ResponseEntity.ok("Propiedad actualizada correctamente.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Propiedad p = service.listId(id);
        if (p == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe una propiedad con el ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Propiedad eliminada correctamente.");
    }

    @GetMapping("/buscar")
    public ResponseEntity<?> buscarPorUbicacion(@RequestParam String distrito) {
        List<Propiedad> lista = service.buscarPorDistrito(distrito);
        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se encontraron propiedades en " + distrito);
        }
        List<PropiedadDTO> listaDTO = lista.stream().map(p -> {
            ModelMapper m = new ModelMapper();
            return m.map(p, PropiedadDTO.class);
        }).collect(Collectors.toList());
        return ResponseEntity.ok(listaDTO);
    }
}