package pe.edu.upc.apisanisidro.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.apisanisidro.Entities.Propiedad;

import java.util.List;

@Repository
public interface PropiedadRepository extends JpaRepository<Propiedad, Integer> {

    // Buscar por distrito o ubicación
    @Query("SELECT p FROM Propiedad p WHERE LOWER(p.distrito) LIKE LOWER(CONCAT('%', :distrito, '%'))")
    List<Propiedad> buscarPorDistrito(@Param("distrito") String distrito);

    // Filtro por rango de precios
    @Query("SELECT p FROM Propiedad p WHERE p.precio BETWEEN :min AND :max")
    List<Propiedad> filtrarPorPrecio(@Param("min") Double min, @Param("max") Double max);

    // Filtro por número de habitaciones
    List<Propiedad> findByHabitaciones(int habitaciones);

    // Ordenar resultados por precio
    List<Propiedad> findAllByOrderByPrecioAsc();
    List<Propiedad> findAllByOrderByPrecioDesc();

    // Buscar propiedades de un usuario (propietario)
    @Query("SELECT p FROM Propiedad p WHERE p.usuario.idUsuario = :idPropietario")
    List<Propiedad> propiedadesPorPropietario(@Param("idPropietario") Integer idPropietario);
}
