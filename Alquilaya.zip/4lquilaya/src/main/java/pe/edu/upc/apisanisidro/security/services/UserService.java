package pe.edu.upc.apisanisidro.security.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.apisanisidro.security.entities.Role;
import pe.edu.upc.apisanisidro.security.entities.User;
import pe.edu.upc.apisanisidro.security.repositories.RoleRepository;
import pe.edu.upc.apisanisidro.security.repositories.UserRepository;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional
    public User save(User user) {
        return userRepository.save(user);
    }

    @Transactional
    public Role saveRole(Role role) {
        return roleRepository.save(role);
    }

    public Integer insertUserRole(Long userId, Long roleId) {
        return userRepository.insertUserRole(userId, roleId);
    }
    
    public List<User> findAll() {
        return userRepository.findAll();
    }
    
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    public Optional<User> findByCorreo(String correo) {
        return userRepository.findByCorreo(correo);
    }
    
    public Optional<User> findByDni(String dni) {
        return userRepository.findByDni(dni);
    }
    
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }
    
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }
    
    public boolean existsByCorreo(String correo) {
        return userRepository.existsByCorreo(correo);
    }
    
    public boolean existsByDni(String dni) {
        return userRepository.existsByDni(dni);
    }
    
    @Transactional
    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }
    
    @Transactional
    public User updatePassword(Long userId, String newPassword) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        user.setPassword(passwordEncoder.encode(newPassword));
        return userRepository.save(user);
    }
    
    @Transactional
    public User enableUser(Long userId, boolean enabled) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        user.setEnabled(enabled);
        return userRepository.save(user);
    }

    // Métodos para roles
    public List<Role> findAllRoles() {
        return roleRepository.findAll();
    }
    
    public Optional<Role> findRoleByName(String name) {
        return roleRepository.findByName(name);
    }
}
