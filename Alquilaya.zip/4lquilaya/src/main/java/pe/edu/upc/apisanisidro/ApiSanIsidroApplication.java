package pe.edu.upc.apisanisidro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSanIsidroApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiSanIsidroApplication.class, args);
    }

}
