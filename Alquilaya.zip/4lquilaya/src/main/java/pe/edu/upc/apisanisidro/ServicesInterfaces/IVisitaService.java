package pe.edu.upc.apisanisidro.ServicesInterfaces;

import pe.edu.upc.apisanisidro.Entities.Visita;

import java.util.List;

public interface IVisitaService {
    public List<Visita> list();
    public void insert(Visita visita);
    public Visita listId(int id);
    public void delete(int id);
    public void edit(Visita visita);
    public List<Visita> visitasPorUsuario(int idUsuario);
}