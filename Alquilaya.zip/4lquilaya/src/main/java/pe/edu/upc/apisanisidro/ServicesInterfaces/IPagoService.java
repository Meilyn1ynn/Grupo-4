package pe.edu.upc.apisanisidro.ServicesInterfaces;

import pe.edu.upc.apisanisidro.Entities.Pago;

import java.util.List;

public interface IPagoService {
    public List<Pago> list();
    public void insert(Pago pago);
    public Pago listId(int id);
    public void delete(int id);
    public void edit(Pago pago);
    public List<Pago> pagosPorContrato(int idContrato);
}