package pe.edu.upc.apisanisidro.ServicesImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.apisanisidro.Entities.Notificacion;
import pe.edu.upc.apisanisidro.Repository.NotificacionRepository;
import pe.edu.upc.apisanisidro.ServicesInterfaces.INotificacionService;

import java.util.List;

@Service
public class NotificacionServiceImplement implements INotificacionService {

    @Autowired
    private NotificacionRepository repository;

    @Override
    public List<Notificacion> list() {
        return repository.findAll();
    }

    @Override
    public void insert(Notificacion notificacion) {
        repository.save(notificacion);
    }

    @Override
    public Notificacion listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(Notificacion notificacion) {
        repository.save(notificacion);
    }

    @Override
    public List<Notificacion> notificacionesPorUsuario(int idUsuario) {
        return repository.listarPorUsuario(idUsuario);
    }
}