package pe.edu.upc.apisanisidro.ServicesInterfaces;

import pe.edu.upc.apisanisidro.Entities.Contrato;
import java.util.List;

public interface IContratoService {
    public List<Contrato> list();
    public void insert(Contrato contrato);
    public Contrato listId(int id);
    public void delete(int id);
    public void edit(Contrato contrato);
    public List<Contrato> contratosPorUsuario(int idUsuario);
}