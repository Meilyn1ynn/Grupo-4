package pe.edu.upc.apisanisidro.ServicesImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.apisanisidro.Entities.ContratoClausula;
import pe.edu.upc.apisanisidro.Repository.ContratoClausulaRepository;
import pe.edu.upc.apisanisidro.ServicesInterfaces.IContratoClausulaService;

import java.util.List;

@Service
public class ContratoClausulaServiceImplement implements IContratoClausulaService {

    @Autowired
    private ContratoClausulaRepository repository;

    @Override
    public List<ContratoClausula> list() {
        return repository.findAll();
    }

    @Override
    public void insert(ContratoClausula clausula) {
        repository.save(clausula);
    }

    @Override
    public ContratoClausula listId(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }

    @Override
    public void edit(ContratoClausula clausula) {
        repository.save(clausula);
    }

    @Override
    public List<ContratoClausula> clausulasPorContrato(int idContrato) {
        return repository.clausulasPorContrato(idContrato);
    }
}