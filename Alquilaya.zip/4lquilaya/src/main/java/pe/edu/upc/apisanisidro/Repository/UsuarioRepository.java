package pe.edu.upc.apisanisidro.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.apisanisidro.Entities.Usuario;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    // Buscar usuario por correo (para login o recuperación)
    Optional<Usuario> findByCorreoUsuario(String correoUsuario);

    // Validar login
    @Query("SELECT u FROM Usuario u WHERE u.correoUsuario = :correo AND u.contrasenaUsuario = :contrasena")
    Optional<Usuario> validarLogin(@Param("correo") String correo, @Param("contrasena") String contrasena);

    // Buscar por nombre o apellido (para filtros o verificación)
    @Query("SELECT u FROM Usuario u WHERE u.nombreUsuario LIKE %:nombre% OR u.apellidoUsuario LIKE %:nombre%")
    List<Usuario> buscarPorNombre(@Param("nombre") String nombre);

    // Verificar existencia de correo o DNI
    boolean existsByCorreoUsuario(String correoUsuario);
    boolean existsByDniUsuario(String dniUsuario);
}
