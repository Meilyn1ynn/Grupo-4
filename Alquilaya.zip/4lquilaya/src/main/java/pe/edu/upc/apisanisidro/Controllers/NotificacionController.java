package pe.edu.upc.apisanisidro.Controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.apisanisidro.DTOs.NotificacionDTO;
import pe.edu.upc.apisanisidro.Entities.Notificacion;
import pe.edu.upc.apisanisidro.ServicesInterfaces.INotificacionService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/notificaciones")
public class NotificacionController {

    @Autowired
    private INotificacionService service;

    @GetMapping
    public List<NotificacionDTO> listar() {
        return service.list().stream().map(n -> {
            ModelMapper m = new ModelMapper();
            return m.map(n, NotificacionDTO.class);
        }).collect(Collectors.toList());
    }

    @PostMapping
    public void insertar(@RequestBody NotificacionDTO dto) {
        ModelMapper m = new ModelMapper();
        Notificacion not = m.map(dto, Notificacion.class);
        service.insert(not);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> listarId(@PathVariable("id") Integer id) {
        Notificacion not = service.listId(id);
        if (not == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe notificación con ID: " + id);
        }
        ModelMapper m = new ModelMapper();
        NotificacionDTO dto = m.map(not, NotificacionDTO.class);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable("id") Integer id) {
        Notificacion not = service.listId(id);
        if (not == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe notificación con ID: " + id);
        }
        service.delete(id);
        return ResponseEntity.ok("Notificación con ID " + id + " eliminada correctamente.");
    }

    @PutMapping
    public ResponseEntity<String> modificar(@RequestBody NotificacionDTO dto) {
        ModelMapper m = new ModelMapper();
        Notificacion not = m.map(dto, Notificacion.class);
        Notificacion existente = service.listId(not.getId());
        if (existente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No se puede modificar. No existe notificación con ID: " + not.getId());
        }
        service.edit(not);
        return ResponseEntity.ok("Notificación con ID " + not.getId() + " modificada correctamente.");
    }
}