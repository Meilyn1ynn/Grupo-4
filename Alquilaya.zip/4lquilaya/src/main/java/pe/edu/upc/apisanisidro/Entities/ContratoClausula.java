package pe.edu.upc.apisanisidro.Entities;

import jakarta.persistence.*;

@Entity
@Table(name = "Contrato_Clausula")
public class ContratoClausula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Cc_id")
    private int idClausula;

    @Column(name = "Cc_texto", nullable = false, columnDefinition = "TEXT")
    private String textoClausula;

    @ManyToOne
    @JoinColumn(name = "Con_id", nullable = false)
    private Contrato contrato;

    public ContratoClausula() {}

    public ContratoClausula(int idClausula, String textoClausula, Contrato contrato) {
        this.idClausula = idClausula;
        this.textoClausula = textoClausula;
        this.contrato = contrato;
    }

    public int getIdClausula() {
        return idClausula;
    }

    public void setIdClausula(int idClausula) {
        this.idClausula = idClausula;
    }

    public String getTextoClausula() {
        return textoClausula;
    }

    public void setTextoClausula(String textoClausula) {
        this.textoClausula = textoClausula;
    }

    public Contrato getContrato() {
        return contrato;
    }

    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }
}
