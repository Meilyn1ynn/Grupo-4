package pe.edu.upc.apisanisidro.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.apisanisidro.Entities.Soporte;

import java.util.List;

@Repository
public interface SoporteRepository extends JpaRepository<Soporte, Integer> {

    // Listar tickets por usuario
    @Query("SELECT s FROM Soporte s WHERE s.usuario.idUsuario = :idUsuario")
    List<Soporte> listarTicketsPorUsuario(@Param("idUsuario") Integer idUsuario);

    // Buscar por estado (abierto, cerrado, pendiente)
    List<Soporte> findByEstado(String estado);
}
