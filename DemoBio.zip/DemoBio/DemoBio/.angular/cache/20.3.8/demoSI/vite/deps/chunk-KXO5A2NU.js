import {
  InjectionToken
} from "./chunk-WBEHRU3H.js";

// node_modules/@angular/material/fesm2022/input-value-accessor.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-KXO5A2NU.js.map
