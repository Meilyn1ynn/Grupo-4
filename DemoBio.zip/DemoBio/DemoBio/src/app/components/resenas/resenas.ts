import { Component } from '@angular/core';
import { Resenaslistar } from './resenaslistar/resenaslistar';
import { ActivatedRoute, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-resenas',
  imports: [RouterOutlet,Resenaslistar],
  templateUrl: './resenas.html',
  styleUrl: './resenas.css',
})
export class Resenas {
  constructor(public route:ActivatedRoute){}

}
