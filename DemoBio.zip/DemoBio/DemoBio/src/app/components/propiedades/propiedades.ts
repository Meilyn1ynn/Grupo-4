import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { Propiedadlistar } from './propiedadlistar/propiedadlistar';

@Component({
  selector: 'app-propiedades',
  imports: [RouterOutlet, Propiedadlistar],
  templateUrl: './propiedades.html',
  styleUrl: './propiedades.css',
})
export class Propiedades {
  constructor(public route:ActivatedRoute){}

}
