import { Component } from '@angular/core';

@Component({
  selector: 'app-contratosearch',
  imports: [],
  templateUrl: './contratosearch.html',
  styleUrl: './contratosearch.css',
})
export class Contratosearch {

}
