import { Component } from '@angular/core';
import { Contratolistar } from './contratolistar/contratolistar';
import { ActivatedRoute, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-contrato',
  imports: [RouterOutlet,Contratolistar],
  templateUrl: './contrato.html',
  styleUrl: './contrato.css',
})
export class Contrato {
  constructor(public route:ActivatedRoute){}

}
