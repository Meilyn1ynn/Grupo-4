import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { Favorito } from '../../../models/Favorito';
import { Usuario } from '../../../models/Usuario';
import { Propiedad } from '../../../models/Propiedad';
import { usuarioservice } from '../../../services/usuarioservice';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { propiedadservice } from '../../../services/propiedadservice';
import { favoritoservice } from '../../../services/favoritoservice';

@Component({
  selector: 'app-favoritosinsertar',
  imports: [MatFormFieldModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatRadioModule,
  ],
  templateUrl: './favoritosinsertar.html',
  styleUrl: './favoritosinsertar.css',
})
export class Favoritosinsertar implements OnInit{
  form: FormGroup = new FormGroup({});
  cont: Favorito = new Favorito();
  id: number = 0;
  today = new Date();
  listaUsuario:Usuario[]=[]
  listaPropiedad:Propiedad[]=[]

  edicion: boolean = false;


  constructor(
    private uS: usuarioservice,
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private pS: propiedadservice,
    private fS: favoritoservice
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((data: Params) => {
      this.id = data['id'];
      this.edicion = data['id'] != null;
      this.init();
    }); 

    this.uS.list().subscribe(data=>{
      this.listaUsuario=data;
    });

    this.pS.list().subscribe(data=>{
    this.listaPropiedad=data;
    });




    this.form = this.formBuilder.group({
      fkUsuario:[''],
      fk2Propiedad:[''],
      idFavorito: ['', Validators.required],
      fecha: ['', Validators.required],
    });
  }
  aceptar(): void {
    if (this.form.valid) {
      this.cont.idFavorito = this.form.value.idFavorito;
      this.cont.fecha = this.form.value.fecha;
      this.cont.usuario.idUsuario = this.form.value.fkUsuario;
      this.cont.propiedad.idPropiedad = this.form.value.fk2Propiedad;
      

      if (this.edicion) {
        this.fS.update(this.cont).subscribe(() => {
          this.fS.list().subscribe((data) => {
            this.fS.setList(data);
          });
        });
      } else {
        this.fS.insert(this.cont).subscribe((data) => {
          this.fS.list().subscribe((data) => {
            this.fS.setList(data);
          });
        });
      }
      this.router.navigate(['contratos']);
    }
  }
  init() {
    if (this.edicion) {
      this.fS.listId(this.id).subscribe((data) => {
        this.form = new FormGroup({
          idFavorito: new FormControl(data.idFavorito),
          fecha: new FormControl(data.fecha),
          usuario:new FormControl(data.usuario.idUsuario),
          propiedad:new FormControl(data.propiedad.idPropiedad)
        });
      });
    }
  }

}
