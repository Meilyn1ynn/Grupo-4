import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { Favoritoslistar } from './favoritoslistar/favoritoslistar';

@Component({
  selector: 'app-favoritos',
  imports: [RouterOutlet,Favoritoslistar],
  templateUrl: './favoritos.html',
  styleUrl: './favoritos.css',
})
export class Favoritos {
  constructor(public route:ActivatedRoute){}

}
