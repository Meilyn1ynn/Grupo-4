import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { Propiedadfotolistar } from './propiedadfotolistar/propiedadfotolistar';

@Component({
  selector: 'app-propiedadfoto',
  imports: [RouterOutlet,Propiedadfotolistar],
  templateUrl: './propiedadfoto.html',
  styleUrl: './propiedadfoto.css',
})
export class Propiedadfoto {
  constructor(public route:ActivatedRoute){}

}
