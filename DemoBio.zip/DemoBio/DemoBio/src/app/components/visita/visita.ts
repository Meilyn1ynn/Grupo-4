import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { Visitalistar } from './visitalistar/visitalistar'; // Asegúrate de importar

@Component({
  selector: 'app-visita',
  imports: [RouterOutlet, Visitalistar],
  templateUrl: './visita.html',
  standalone: true,
})
export class Visita {
  constructor(public route: ActivatedRoute) {}
}