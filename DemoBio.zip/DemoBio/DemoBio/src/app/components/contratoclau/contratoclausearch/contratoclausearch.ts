import { Component } from '@angular/core';

@Component({
  selector: 'app-contratoclausearch',
  imports: [],
  templateUrl: './contratoclausearch.html',
  styleUrl: './contratoclausearch.css',
})
export class Contratoclausearch {

}
