import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { Contratoclaulistar } from "./contratoclaulistar/contratoclaulistar";
import { Contratolistar } from '../contrato/contratolistar/contratolistar';

@Component({
  selector: 'app-contratoclau',
  imports: [RouterOutlet,Contratoclaulistar],
  templateUrl: './contratoclau.html',
  styleUrl: './contratoclau.css',
})
export class Contratoclau {
  constructor(public route:ActivatedRoute){}

}
