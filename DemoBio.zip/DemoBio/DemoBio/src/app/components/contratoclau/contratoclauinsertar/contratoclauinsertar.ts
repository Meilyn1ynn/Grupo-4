import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { ContratoClau } from '../../../models/ContratoClau';
import { Contrato } from '../../../models/Contrato';
import { contratoClauservice } from '../../../services/contratoClauservice';
import { contratoservice } from '../../../services/contratoservice';
import { ActivatedRoute, Params, Router } from '@angular/router';


@Component({
  selector: 'app-contratoclauinsertar',
  imports: [MatFormFieldModule,
      ReactiveFormsModule,
      MatButtonModule,
      MatInputModule,
      MatDatepickerModule,
      MatNativeDateModule,
      MatSelectModule,
      MatRadioModule,],
  templateUrl: './contratoclauinsertar.html',
  styleUrl: './contratoclauinsertar.css',
})
export class Contratoclauinsertar implements OnInit{
  form: FormGroup = new FormGroup({});
  cont: ContratoClau = new ContratoClau();
  id: number = 0;
  today = new Date();
  listaContrato:Contrato[]=[]

  edicion: boolean = false;


  constructor(
    private lS: contratoClauservice,
    private cS: contratoservice,
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((data: Params) => {
      this.id = data['id'];
      this.edicion = data['id'] != null;
      this.init();
    }); 

    this.cS.list().subscribe(data=>{
      this.listaContrato=data;
    });





    this.form = this.formBuilder.group({
      fkContrato:[''],
      idClausula: ['', Validators.required],
      textoClausula: ['', Validators.required],
    });
  }
  aceptar(): void {
    if (this.form.valid) {
      this.cont.idClausula = this.form.value.idClausula;
      this.cont.textoClausula = this.form.value.textoClausula;
      this.cont.contrato.idContrato = this.form.value.fkContrato;


      

      if (this.edicion) {
        this.lS.update(this.cont).subscribe(() => {
          this.lS.list().subscribe((data) => {
            this.lS.setList(data);
          });
        });
      } else {
        this.lS.insert(this.cont).subscribe((data) => {
          this.lS.list().subscribe((data) => {
            this.lS.setList(data);
          });
        });
      }
      this.router.navigate(['ContratoClausula']);
    }
  }
  init() {
    if (this.edicion) {
      this.lS.listId(this.id).subscribe((data) => {
        this.form = new FormGroup({

          
          idClausula: new FormControl(data.idClausula),
          textoClausula: new FormControl(data.textoClausula),
          contrato: new FormControl(data.contrato.idContrato)
        });
      });
    }
  }


}
