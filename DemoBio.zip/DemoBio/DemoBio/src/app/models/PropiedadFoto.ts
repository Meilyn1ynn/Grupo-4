import { Propiedad } from "./Propiedad"

export class PropiedadFoto{
idFoto:number=0
url:string=""
propiedad:Propiedad=new Propiedad()
}